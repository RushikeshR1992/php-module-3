<?php
include("header.php");
include("update.php");
   
$editId =$_GET['editId'];

    $sql="select * from fruit_manager where f_id=$editId";

    // echo $sql; exit();
    $run=$conn->query($sql);

    $fetch=mysqli_fetch_array($run)
    
?>

<body>
<div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-6">

                <div>
                    <h1>Edit User</h1>
                    <a href="index.php" class="btn btn-primary">Go Back</a>
                </div>
                <form method="post" enctype="multipart/form-data">

                    <div class="mb-3">
                        <label class="form-label">Enter Fruit Name</label>
                        <input type="text" name="f_name" value="<?php echo $fetch['f_name']; ?>" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Qty</label>
                        <input type="number" name="f_qty" value="<?php echo $fetch['f_qty']; ?>" min="1" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label  class="form-label">Enetr Price</label>
                        <input type="number" name="f_price" value="<?php echo $fetch['price']; ?>" min="1" class="form-control" placeholder="for KG">
                    </div>
                    <div class="mb-3">
                      <input type="submit" name="submit">
                    </div>

</body>
</html>