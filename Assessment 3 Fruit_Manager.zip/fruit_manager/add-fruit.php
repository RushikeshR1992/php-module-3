<?php 
include("header.php");
include("insert.php");
?>


<body>
<div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-6">

                <div>
                    <h1>Add User</h1>
                    <a href="index.php" class="btn btn-primary">Go Back</a>
                </div>
                <form method="post" enctype="multipart/form-data">

                    <div class="mb-3">
                        <label class="form-label">Enter Fruit Name</label>
                        <input type="text" name="f_name" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Qty</label>
                        <input type="number" name="f_qty" min="1" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label  class="form-label">Enetr Price</label>
                        <input type="number" name="f_price" min="1" class="form-control" placeholder="for KG">
                    </div>
                    <div class="mb-3">
                      <input type="submit" name="submit">
                    </div>

</body>
</html>