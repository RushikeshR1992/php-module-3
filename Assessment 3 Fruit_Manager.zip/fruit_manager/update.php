<?php

$editId =$_GET['editId'];

// echo "$editId";

if(isset($_POST['submit']))
{
    $f_name=$_POST['f_name'];
    $f_qty=$_POST['f_qty'];
    $f_price=$_POST['f_price'];

    $sql="update fruit_manager set f_name='$f_name',f_qty='$f_qty',price='$f_price' where f_id='$editId'";

    // echo "$sql"; exit();
    $run=$conn->query($sql);

    if($run)
    {
        header('location:index.php');
    }
}

// "update fruit_manager set "