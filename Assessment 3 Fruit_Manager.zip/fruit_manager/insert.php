<?php

include("connection.php");

if(isset($_POST['submit']))
{
    $f_name=$_POST['f_name'];
    $f_qty=$_POST['f_qty'];
    $f_price=$_POST['f_price'];

    $sql="insert into fruit_manager (f_name,f_qty,price) values ('$f_name','$f_qty','$f_price')";

    // echo $sql;
    $run=mysqli_query($conn,$sql);
    
    if($run)
    {
        header('location:index.php');
    }
}
