<?php
include("header.php");

$viewid = $_GET['viewid'];

// echo $showId; exit();

$sql = "select * from fruit_manager where f_id=$viewid";

$run = $conn->query($sql);

// $siglefetch = mysqli_fetch_array($run);

$row = $run->fetch_object();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>
</head>

<body>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
  </head>

  <body>
    <div class="card" style="width: 18rem;">
      <!-- <img src="..." class="card-img-top" alt="..."> -->
      <div class="card-body">
        <h5 class="card-title">Id:<?php echo $row->f_id; ?></h5>
        <p class="card-text">Name:<?php echo $row->f_name ?></p>
        <p class="card-text">Qty:<?php echo $row->f_qty ?></p>
        <p class="card-text">Price:<?php echo $row->price ?></p>
      </div>
    </div>
  </body>

  </html>
</body>

</html>