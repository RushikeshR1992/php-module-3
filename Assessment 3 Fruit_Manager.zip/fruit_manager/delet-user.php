<?php 

    
    include("connection.php");
    
    $delId=$_GET['delId'];
    // echo $delId; //show the id
    $sql="delete from fruit_manager where f_id=$delId";
    $run=$conn->query($sql);

    if($run)
    {
        header("location:index.php");
    }