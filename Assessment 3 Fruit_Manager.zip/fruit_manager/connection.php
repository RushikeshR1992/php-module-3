<?php
$conn =mysqli_connect('localhost','root','','fruit_manager');

// if($conn)
// {   
//     echo "Connected";
// }