<?php
include("header.php");


$select="select * from fruit_manager";

$run=mysqli_query($conn,$select);
?>

  <div class="container">
    <div class="row">
      <div class="col-6">
      <table class="table">
  <thead>
    <a href="add-fruit.php">Go Back</a>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Fruit Name</th>
      <th scope="col">Qty</th>
      <th scope="col">Price</th>
      <th scope="col">Sub Total</th>
    </tr>
  </thead>
  <?php
    while($row=mysqli_fetch_array($run))
    {
  ?>
  <tbody>
    <tr>
      <td><?php echo $row['f_id']; ?></td>
      <td><?php echo $row['f_name'];?></td>
      <td><?php echo $qty=$row['f_qty']; ?></td>
      <td><?php echo $row['price']; ?></td>
      <td><?php echo $tot=$qty*$row['price']; ?></td>

      <td>


      
      
      <a href="view-user.php?viewid=<?php echo $row['f_id'] ?>" class="btn btn-info"><i class="fa-solid fa-user"></i></a>

        <a href="edit-user.php?editId=<?php echo $row['f_id']; ?>" class="btn btn-warning"><i class="fa-solid fa-pen-to-square"></i></a>
        <a href="delet-user.php?delId=<?php echo $row['f_id']; ?>" class="btn btn-danger"><i class="fa-solid fa-trash"></i></a>
      </td>
    </tr>
<?php
    }
?>


      <?php
while($row=(mysqli_fetch_array($run)))
{
    ?>
      <h1><?php echo $row['f_id']; ?></h1>
    <h2><?php echo $row['f_name']; ?></h2>
  
  <?php
}
?>


     




  </tbody>
</table>
      </div>
    </div>
  </div>