<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js"
        integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container pt-5">
        <div class="row justify-content-center">
            <div class="col-xl-6">
                <form action="" id="formId" class="form-control">
                    <div class="mb-3">
                        <label for="" class="form-label"></label>
                        Name:<input type="text" name="name" id="name">
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label"></label>
                        Email:<input type="text" name="email" id="email">
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label"></label>
                        Age:<input type="text" name="age" id="age">
                    </div>
                    <input type="submit" value="submit" class="btn btn-primary" name="submit" id="submit">
                    <input type="submit" value="update" class="btn btn-info" hidden name="update"  id="update">
                </form>
                <div id="tbl"></div>
            </div>
        </div>
    </div>
</body>

</html>

<script>

    function ajaxArr(x) {
        const arre = $(x).serializeArray();
        console.log(arre);

        const arr = {};
        for (i = 0; i < arre.length; i++) {
           
            arr[arre[i].name] = arre[i].value;
        }
        const str =JSON.stringify(arr);
        return str;
        // console.log(str);
    }
// insert
    $('#submit').on('click', function (e) {
        e.preventDefault();

        const data = ajaxArr('#formId');

        $.ajax({
            url:'insert.php',
            type:'post',
            data:data,
            success:function (res) {
                console.log(res);                
                getAll();
            }
        })

    })
    // fetchall data
    getAll();
    function getAll(){

        $.ajax({
            url:'show.php',
            type:'get',
            success:function (res){
                // console.log(res);
                $('#tbl').html(res);
            }
        })
    }

// edit

$(document).on('click','.edit',function(){
    const id=$(this).attr('id');

    $('#submit').prop('hidden',true);
    $('#update').prop('hidden',false);

    $.ajax({
        url:'edit.php',
        type:'get',
        data:{id:id},
        success:function (res){
            // console.log(res);

            $('#id').val(res.id);
            $('#name').val(res.name);
            $('#email').val(res.email);
            $('#age').val(res.age);
        }
    })
})

// update

$('#update').on('click',function(e){
    e.preventDefault();

    const arr = ajaxArr('#formId');

    console.log(arr);

    $.ajax({
        url:'update.php',
        type:'post',
        data:arr,
        success:function(res){
            
            
            console.log(res);
            $('#formId')[0].reset();
            getAll();
        }
    })
})

// delete

// $(document).on('click','.delete',function(){

//     id =$(this).attr('id');
//     $.ajax({
//         url:'delete.php',
//         type:'get',
//         data:{id:id},
//         success:function(res){
//             console.log(res);
//             getAll();
//         }
//     })
// })
</script>