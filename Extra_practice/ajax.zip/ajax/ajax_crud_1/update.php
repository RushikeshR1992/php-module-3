<?php
include("connection.php");

header('content-type:application/json');

$data = json_decode(file_get_contents('php://input'));

$id = $data->id;
$name =$data->name;
$email = $data->email;
$age = $data->age;

$sql = "update ajax_1_try set name = '{$name}',email = '{$email}',age = '{$age}' where id = $id";

// echo $sql;
// exit();
$run = $conn->query($sql);

if($run)
{
    echo json_encode('success');
}