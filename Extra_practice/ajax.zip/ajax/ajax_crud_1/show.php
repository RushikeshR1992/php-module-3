<?php
include("connection.php");

$sql = "select * from ajax_1_try";

$run = mysqli_query($conn, $sql);

$data = '';

if ($run) {
    $data .= "<table class='table table-dark'>
    <thead>
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Email</th>
        <th>Age</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>";
    while ($fetch = mysqli_fetch_assoc($run)) {
        $data .= "<tr>
            <td>" . $fetch['id'] . "</td>
            <td>" . $fetch['name'] . "</td>
            <td>" . $fetch['email'] . "</td>
            <td>" . $fetch['age'] . "</td>
            <td><a class='btn btn-primary edit'id ='" . $fetch['id'] . "'>Edit</a> </td>
            <td><a class='btn btn-danger delete'id='" . $fetch['id'] . "'>Delete</a></td>
        </tr>";
    }
    $data .= "</tbody>
    </table>";

    echo $data;
}
