<?php
include("connection.php");

header('content-type:application/json');

$id=$_GET['id'];

$sql = "delete from ajax_crud where id=$id";

$run = mysqli_query($conn, $sql);



