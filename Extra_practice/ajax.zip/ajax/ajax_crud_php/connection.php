<?php

$conn=new mysqli('localhost','root','','extra_practice');

// if($conn)
// {
//     // echo "connected";
// }