    <?php

include("connection.php");

$sql = "select * from ajax_crud";

$run = mysqli_query($conn, $sql);
$data = '';
if ($run) {

    $data .= "<table class='table tabel-boredered'>
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Age</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>";
    while ($var = mysqli_fetch_assoc($run)) {
        $data .=
            "<tr>
        <td>" . $var['name'] . "</td>
        <td>" . $var['email'] . "</td>
        <td>" . $var['age'] . "</td>
        <td><a class='btn btn-primary edit' id = '" . $var['id'] . "'>Edit</a></td>
        <td><a class='btn btn-danger delete' id = '" . $var['id'] . "'>Delete</a></td>
    </tr>";
    }
    $data .= "</tbody>
</table>";

    echo $data;
}
