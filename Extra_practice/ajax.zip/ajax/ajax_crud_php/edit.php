<?php
include("connection.php");

header('content-type:application/json');

$id=$_GET['id'];

$sql = "select * from ajax_crud where id=$id";

$run = mysqli_query($conn, $sql);

if($run)
{
    $data=mysqli_fetch_assoc($run);

    echo json_encode($data);
}

