<?php
include("header.php");
?>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6">
                <form method="post" id="formid">
                    <div class="mb-3">

                        <input type="text" name="id" id="id" hidden class="form-control">

                        <label class="form-label">Name</label>
                        <input type="text" name="name" id="name" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">email</label>
                        <input type="email" name="email" id="email" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">age</label>
                        <input type="text" name="age" id="age" class="form-control">
                    </div>
                    <button type="submit" name="submit" id="submit" class="btn btn-primary">Submit</button>
                    <button type="submit" name="update" id="update" hidden class="btn btn-primary">update</button>
                </form>
                <div id="table"></div>
            </div>
        </div>
    </div>

</body>


</html>

<script>
    getall();

    function getall() {
        $.ajax({
            url: 'show.php',
            type: 'get',
            success: function (res) {

                // console.log(res);
                // document.write(res);

                $('#table').html(res);
            }
        })
    }

    function jasonData(x) {
        const arr = $(x).serializeArray();
        // console.log(arr);

        const obj = {};

        for (i = 0; i < arr.length; i++) {
            obj[arr[i].name] = arr[i].value;
        }
        const str = JSON.stringify(obj);
        return str;
    }
    $('#submit').on('click', function (e) {
        e.preventDefault();


        const data = jasonData('#formid');

        console.log(data);
        $.ajax({
            url: 'insert.php',
            method: 'post',
            data: data,
            success: function (res) {
                console.log(res);
                getall();
            }

        })
    })
    // edit

    $(document).on('click', '.edit', function () {
        id = $(this).attr('id');
        $('#submit').prop('hidden', true);
        $('#update').prop('hidden', false);
        // console.log(id);
        $.ajax({
            url: 'edit.php',
            method: 'get',
            data: { id: id },
            success: function (res) {
                // console.log(res);
                $('#id').val(res.id);
                $('#name').val(res.name);
                $('#email').val(res.email);
                $('#age').val(res.age);
            }

        })
    })
    // update

    $('#update').on('click', function (e) {
        e.preventDefault();


        const data = jasonData('#formid');

        console.log(data);
        $.ajax({
            url: 'update.php',
            method: 'post',
            data: data,
            success: function (res) {
                console.log(res);
                $('#update').prop('hidden', true);
                $('#submit').prop('hidden', false);
                $('#formid')[0].reset();
                getall();
            }
        })
    })
// delete
$(document).on('click', '.delete', function () {
        id = $(this).attr('id');
       
        // console.log(id);
        $.ajax({
            url: 'delete.php',
            method: 'get',
            data: { id: id },
            success: function (res) {
                console.log(res);
                getall();
                // $('#id').val(res.id);
                // $('#name').val(res.name);
                // $('#email').val(res.email);
                // $('#age').val(res.age);
            }

        })
    })
    

</script>