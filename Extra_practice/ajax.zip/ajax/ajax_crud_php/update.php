<?php

include("connection.php");

header('content-type:application/json');
$data = json_decode(file_get_contents("php://input"));

$id=$data->id;
$name = $data->name;
$email = $data->email;
$age = $data->age;

$sql = "update ajax_crud set name='{$name}',email='{$email}',age='{$age}' where id=$id";

$run = mysqli_query($conn,$sql);

if($run)
{
    echo json_encode('success');
}
?>


