<?php

include("connection.php");

header('content-type:application/json');

$eid=$_GET['eid'];

$sql="delete from ajax_crud where id=$eid";

$run=mysqli_query($conn,$sql);



if($run)
{
   
    echo json_encode("success");
}