<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="jquery-cdnjs.js"></script>
</head>

<body>
    <form action="" method="post" style="padding-left: 150px;padding-top:50px;border:1px" id="formData">
        Name: <input type="text" name="name" id="name"><br><br>
        <input type="text" hidden name="uid" id="uid">
        Age: <input type="text" name="age" id="age"><br><br>
        email: <input type="text" name="email" id="email">
        <input type="submit" name="btn" id="btn">
        <input type="submit" value="update" id="btn1" hidden>
    </form>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody id="tbody"></tbody>
    </table>
</body>
<script>

    function getall() {
        const tbody = $("#tbody").html('');
        $.ajax({
            url: "getall.php",
            type: "get",
            success: function (res) {
                // console.log(res);
                $.each(res, function (i, v) {
                        tbody.append(`<tr>
                                        <td>${v.name}</td>
                                        <td>${v.age}</td>
                                        <td>${v.Language}</td>
                                        <td><a class="edit" id="${v.id}">Edit</td>
                                        <td><a class="delete" id="${v.id}">Delete</td>
                                     </tr>`);

                })
                $('.edit').click(function () {
                    $('#btn').prop('hidden', true);
                    $('#btn1').prop('hidden', false);

                    id = $(this).attr('id');
                    // console.log(id);
                    $.ajax({
                        url: "edit.php",
                        type: "get",
                        data: { eid: id },
                        success: function (res) {
                            // console.log(res);
                            $('#name').val(res.name);
                            $('#uid').val(res.id);
                            $('#age').val(res.age);
                            $('#email').val(res.Language);
                        }
                    })
                })
                //delete

                $('.delete').click(function () {

                    id = $(this).attr('id');
                    // console.log(id);
                    $.ajax({
                        url: "delete.php",
                        type: "get",
                        data: { eid: id },
                        success: function (res) {
                            console.log(res);
                            getall();
                            // $('#name').val(res.name);
                            // $('#uid').val(res.id);
                            // $('#age').val(res.age);
                            // $('#email').val(res.Language);
                        }
                    })
                })
            }
        })
    }

    //update

    $('#btn1').on("click", function (e) {
        e.preventDefault();
        const obj = jsonData("#formData");

        // console.log(obj);

        $.ajax({
            url: "update.php",
            method: "post",
            data: obj,
            success: function (res) {
                console.log(res);
                getall();
                $('#name').val('');
                $('#age').val('');
                $('#email').val('');

                $('#btn').prop('hidden', false);
                $('#btn1').prop('hidden', true);
            }
        });

    })
    getall();
    $('#btn').on("click", function (e) {
        e.preventDefault();
        const obj = jsonData("#formData");

        // console.log(obj);

        $.ajax({
            url: "insert.php",
            method: "post",
            data: obj,
            success: function (res) {
                console.log(res);
                getall();
                $('#name').val('');
                $('#age').val('');
                $('#email').val('');
            }
        });

    })

    function jsonData(x) {
        const arr = $(x).serializeArray();
        const obj = {};

        for (i = 0; i < arr.length; i++) {
            obj[arr[i].name] = arr[i].value;
        }

        const str = JSON.stringify(obj);

        return str;
    }

</script>

</html>