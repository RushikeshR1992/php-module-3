<?php

include("connection.php");

header('content-type:application/json');

$eid=$_GET['eid'];

$sql="select * from ajax_crud where id=$eid";

$run=mysqli_query($conn,$sql);



if($run)
{
    $result = mysqli_fetch_assoc($run);
    echo json_encode($result);
}