<?php

$conn = mysqli_connect('localhost', 'root', '', 'extra_practice');
if (!$conn) {
    echo "error";
}