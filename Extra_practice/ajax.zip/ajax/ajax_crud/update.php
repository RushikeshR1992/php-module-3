<?php

include("connection.php");

header('content-type:application/json');

$data=json_decode(file_get_contents("php://input"));

$uid=$data->uid;
$name=$data->name;
$age=$data->age;
$email=$data->email;

$sql="update ajax_crud set name='{$name}',age='{$age}',Language='{$email}' where id=$uid";

$run=mysqli_query($conn,$sql);

if($run)
{
    echo json_encode(array("message","your data updated"));
}