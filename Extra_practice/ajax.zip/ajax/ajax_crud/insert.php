<?php

include("connection.php");

header('content-type:application/json');

$data=json_decode(file_get_contents("php://input"));

$name=$data->name;
$age=$data->age;
$lang=$data->email;

$sql="insert into ajax_crud (name,age,Language) values ('{$name}','{$age}','{$lang}')";

$run=mysqli_query($conn,$sql);

if($run)
{
    echo json_encode(array("message","your data inserted"));
}