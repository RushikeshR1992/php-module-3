<?php

include("connection.php");

header('content-type:application/json');

$sql="select * from ajax_crud";

$run=mysqli_query($conn,$sql);



if($run)
{
    $result = mysqli_fetch_all($run,MYSQLI_ASSOC);
    echo json_encode($result);
}