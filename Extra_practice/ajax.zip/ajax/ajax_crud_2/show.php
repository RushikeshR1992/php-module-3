<?php

include("db.php");

$sql="select * from ajax_1_try";
$run = mysqli_query($conn,$sql);
$data ='';

if($run){

    $data.="<table>
                <thead>
                    <tr>
                      <td>Id</td>
                      <td>Name</td>
                      <td>Email</td>
                      <td>Age</td>
                    </tr>
                </thead>
                <tbody>";
                while($r = mysqli_fetch_assoc($run)){

                    $data.="<tr>
                        <td>". $r['id'] ."</td>
                        <td>". $r['name'] ."</td>
                        <td>". $r['email'] ."</td>
                        <td>". $r['age'] ."</td>
                        <td><a class='btn btn-primary edit'id ='". $r['id'] ."'>Edit</a></td>
                        <td><a class='btn btn-primary edit'id ='" . $r['id'] . "'>Edit</a> </td>
                        <td><a class='btn btn-danger delete'id ='". $r['id'] ."'>Delete</a></td>
                    </tr>";
                }
                $data.="</tbody>
            </table>";
            echo $data;
}

