<?php

include("db.php");

header('content-type:application/json');

$data = json_decode(file_get_contents('php://input'));

$name = $data->name;
$email = $data->email;
$age = $data->age;

$sql = "insert into ajax_1_try (name,email,age) values ('{$name}','{$email}','{$age}')";

$run = mysqli_query($conn, $sql);

if ($run) {
    echo json_encode('success');    
}
