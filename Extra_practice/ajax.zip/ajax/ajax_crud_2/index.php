<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.7.1.js"
        integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6">
                <form method="post" id="formid">
                    <div class="mb-3">

                        <input type="text" name="id" id="id" class="form-control">

                        <label class="form-label">Name</label>
                        <input type="text" name="name" id="name" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">email</label>
                        <input type="email" name="email" id="email" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">age</label>
                        <input type="text" name="age" id="age" class="form-control">
                    </div>
                    <button type="submit" name="submit" id="submit" class="btn btn-primary">Submit</button>
                    <button type="submit" name="update" id="update" hidden class="btn btn-primary">update</button>
                </form>
                <div id="table"></div>
            </div>
        </div>
    </div>
 <script>
        
        getall();
        function getall(){
            $.ajax({
                url:'show.php',
                type:'get',
                success:function(res){
                    // console.log(res);
                    $('#table').html(res);
                }
            })
        }
        function ajaxarre(x) {
            const arre = $(x).serializeArray();
            // console.log(arre);

            const vare = {};
            for (i = 0; i < arre.length; i++) {
                vare[arre[i].name] = arre[i].value;
            }
            const str = JSON.stringify(vare);
            return str;
        }

        $('#submit').on('click', function (e) {
            e.preventDefault();
            var arr = ajaxarre('#formid');

            // console.log(arr);

            $.ajax({
                url: 'insert.php',
                type: 'post',
                data: arr,
                success: function (res) {
                    console.log(res);
                }
            })

        })
        $(document).on('click','.edit',function () {
             id = $(this).attr('id');
                console.log(id);
                
            $.ajax({
                url:'edit.php',
                type:'get',
                data:{id :id},
                success:function(res){
                    // console.log(res.);

                    $('#id').val(res.id);
                    $('#name').val(res.name);
                    $('#email').val(res.email);
                    $('#age').val(res.age);
                    
                }
            })
            
        })


    </script>