<?php $__env->startSection('content'); ?>




<main id="main" class="main">

  <div class="pagetitle">
    <h1>Login</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
        <li class="breadcrumb-item"><a href="register">Registartion</a></li>
        <li class="breadcrumb-item active">Login</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->
  <div class="container">

    <section class="section register min-vh-85 d-flex flex-column align-items-center justify-content-center">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-6 d-flex flex-column align-items-center justify-content-center">

            <div class="d-flex justify-content-center py-2">
              <a href="dashbord.php" class="btn btn-primary d-flex align-items-center w-auto">
                <span class="d-none d-lg-block">GoBAck</span>
              </a>
            </div><!-- End Logo -->

            <div class="card mb-5">

              <div class="card-body">


                <form method="post">
                  <p>Please login to your account</p>

                  <div class="mb-4">
                    <input type="email" id="form2Example11" name="username" class="form-control"
                      placeholder="Phone number or email address" />
                    <label class="form-label" for="form2Example11">Username</label>
                  </div>

                  <div class="mb-4">
                    <input type="password" id="form2Example11" name="password" class="form-control"
                      placeholder="Enter Password" />
                    <label class="form-label" for="form2Example22">Password</label>
                  </div>

                  <div class="mb-4">
                    <input type="checkbox" id="form2Example22" name="remember" />
                    <label class="form-label" for="form2Example22">Remember me</label>
                  </div>

                  <div class="pt-1 mb-5 pb-1">
                    <button class="btn btn-primary btn-block fa-lg gradient-custom-2 mb-3" type="submit"
                      name="login">Log in</button>
                    <a class="text-muted" href="#!">Forgot password?</a>
                  </div>

                  <!-- <div class="d-flex align-items-center justify-content-center pb-4">
                    <p class="mb-0 me-2">Don't have an account?</p>
                    <button  type="submit" name="submit" class="btn btn-outline-danger">Create new</button>
                  </div> -->

                </form>

              </div>
            </div>

            <div class="credits">
              <!-- All the links in the footer should remain intact. -->
              <!-- You can delete the links only if you purchased the pro version. -->
              <!-- Licensing information: https://bootstrapmade.com/license/ -->
              <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->

            </div>

          </div>
        </div>
      </div>

    </section>

  </div>
</main><!-- End #main -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\php_assessment\assessment_laravel\resources\views/admin/index.blade.php ENDPATH**/ ?>