<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmasy System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <!-- cdnjs json file -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"
        integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
</head>

<body>
    <div class="conatiner ">
        <div class="row justify-content-center mt-5">
            <div class="col-xl-3">

                <select name="" id="var">
                    <option value="" default>Select</option>
                    <option value="admin">
                        Admin
                    </option>
                    <option value="user">
                        User
                    </option>
                </select>
                <form method="post">
                    <p>Please login to your account</p>
                    <div class="form-outline mb-4">
                        <label class="form-label" for="form2Example11">Email</label>
                        <input type="email" id="email" name="email" class="form-control"
                            placeholder="Phone number or email address" />
                        <span id="eremail"></span>
                    </div>

                    <div class="form-outline mb-4">
                        <label class="form-label" for="form2Example22">Password</label>
                        <input type="password" id="pass" name="password" class="form-control"
                            placeholder="Enter Your Password" />
                        <span id="erpass"></span>
                    </div>
                    <div class="form-outline mb-4">
                        <input type="button" value="submit" id="btn" name="submit" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
<script>

    var email = $('#email').val();
    var pass = $('#pass').val();


    $('#btn').on('click', function () {

        if ($('#var').val() != '') {

            var email = $('#email').val();
            var pass = $('#pass').val();

            // console.log('admin');
            if ($('#var').val() == 'admin') {

                $.ajax({

                    url: "<?php echo e(route('admincheck')); ?>",
                    type: 'get',
                    data: { email: email, pass: pass },

                    success: function (res) {

                        // console.log(res);

                        if (res == 'True') {
                            window.location.href = "<?php echo e(route('adminindex')); ?>"
                        }
                    }
                })
            }

        } else {
            alert('Choose Pannel');
        }

    })
    $('#btn').on('click', function () {
        if ($('#var').val() != '') {

            var email =$('#email').val();
            var pass =$('#pass').val();
            // console.log('user');

            if($('#var').val() == 'user'){

                $.ajax({
                    url:'<?php echo e(route('usercheck')); ?>',
                    type: 'get',
                    data:{email:email,pass:pass},
                    success:function(res){
                        console.log(res);
                        if(res== 'true'){
                            window.location.href='<?php echo e(route('index')); ?>';
                        }
                    }
                })
            }

        }
    })

</script>
<?php /**PATH D:\xampp\htdocs\php_assessment\assessment_laravel\resources\views/index.blade.php ENDPATH**/ ?>