<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-xl-6">

            <main id="main" class="main">
                <div>

                        <h3 id="content"></h3>

                </div>
                <!-- Browser Default Validation -->
                <form class="row g-3" id="formdata" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="col-md-12">
                        <label for="validationDefault01" class="form-label">First name</label>
                        <input type="text" class="form-control" name="uname" id="uname">
                        <p id="errname"></p>
                    </div>
                    <div class="col-md-12">
                        <label for="validationDefaultUsername" class="form-label">Email</label>
                        <div class="input-group">
                            <span class="input-group-text" id="">@</span>
                            <input type="text" name="uemail" class="form-control" id="uemail">
                        </div>
                        <p id="erremail"></p>
                    </div>
                    <div class="col-md-12">
                        <label for="validationDefault03" class="form-label">Password</label>
                        <input type="text" class="form-control" name="upass" id="upass">
                        <p id="errpass"></p>
                    </div>
                    <div class="col-md-12">
                        <label for="validationDefault04" class="form-label">confirm-Password</label>
                        <input type="text" name="ucpass" class="form-control" id="ucpass">
                        <p id="errcpass"></p>
                    </div>
                    <div class="col-md-12">
                        <label for="validationDefault04" class="form-label">Mobile</label>
                        <input type="number" class="form-control" name="umobile" id="umobile">
                        <p id="errmob"></p>
                    </div>


                    <div class="col-md-12">
                        <label for="validationDefault04" class="form-label">Gender</label>

                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="ugender" id="umale" value="male">
                            <label class="form-check-label">
                                Male
                            </label>

                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="ugender" id="ufmale" value="female">
                            <label class="form-check-label"> Female
                            </label>
                            <p id="errmale"></p>
                        </div>

                        <div class="col-md-12">
                            <label for="validationDefault04" class="form-label">Languges</label>

                            <div class="form-check">
                                <input class="form-check-input" name="chk[]" type="checkbox" value="English" id="eng">
                                <label class="form-check-label">
                                    English
                                </label>

                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="chk[]" type="checkbox" value="Gujarati" id="guj">
                                <label class="form-check-label">
                                    Gujarati
                                </label>

                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="chk[]" type="checkbox" value="Hindi" id="hid">
                                <label class="form-check-label">
                                    Hindi
                                </label>
                                <p id="lang"></p>
                            </div>
                        </div>
                        <div class="md-12">
                            <label class="form-label">Address</label>
                            <input type="text" class="form-control" name="uaddress" id="uaddress">
                            <p id="erradd"></p>
                        </div>

                        <div class="col-md-3">
                            <label for="validationDefault04" class="form-label">Images</label>
                            <input type="file" name="uimage" id="img">
                            <p id="errimg"></p>
                        </div>
                        <div class="col-md-12">
                            <label for="validationDefault03" class="form-label">Date-Time</label>
                            <input type="datetime-local" class="form-control" name="date_time" id="date-time">
                        </div>

                        <div class=" pt-3">
                            <button class="btn btn-primary" type="submit" id="btn" name="submit"
                                onclick="return validate()">Submit form</button>
                        </div>
                </form>
                <!-- End Browser Default Validation -->


            </main><!-- End #main -->
        </div>
    </div>
</div>

<script>


    uname = document.getElementById('uname');
    email = document.getElementById('uemail');
    pass = document.getElementById('upass');
    cpass = document.getElementById('ucpass');
    mobile = document.getElementById('umobile');
    male = document.getElementById('umale');
    fmale = document.getElementById('ufmale');
    eng = document.getElementById('eng');
    guj = document.getElementById('guj');
    hid = document.getElementById('hid');
    address = document.getElementById('uaddress');
    img = document.getElementById('img');


    // Err

    errname = document.getElementById('errname');
    erremail = document.getElementById('erremail');
    epass = document.getElementById('errpass');
    ecpass = document.getElementById('errcpass');
    errmob = document.getElementById('errmob');
    errmale = document.getElementById('errmale');
    lang = document.getElementById('lang');
    erradd = document.getElementById('erradd');
    errimg = document.getElementById('errimg');

    function validate() {


        //===================== name ==================================
        if (uname.value == '') {
            errname.innerHTML = 'Enter Name';
            errname.style.color = "red";

            return false;
        } else {
            errname.innerText = '';
        }
        //======================== Email =====================================
        if (email.value == '') {
            erremail.innerHTML = "Enter Email";
            erremail.style.color = "red";
            return false;
        }
        else {
            erremail.innerText = '';
        }


        // // ===================Password or co-password=======================


        if (pass.value == '') {
            epass.innerHTML = "Enter Your password";
            epass.style.color = "red";

            return false;
        }
        else {
            epass.innerHTML = '';
        }
        if (cpass.value == '') {
            ecpass.innerHTML = "Enter Your co-password";
            ecpass.style.color = "red";

            return false;
        }
        else {
            ecpass.innerHTML = '';
        }
        if (pass.value !== cpass.value) {
            errcpass.innerHTML = "Enter Correct Password";
            errcpass.style.color = "red";
            return false;
        }
        // ======================MObile No=========================
        // console.log(mobile.value.length);

        if (mobile.value == '') {
            errmob.innerHTML = "Enter Mobile No";
            errmob.style.color = "red";

            return false;
        }
        else if (mobile.value.length != 10) {
            mobile.value = '';
            errmob.innerHTML = "Enter The Valid Number";
            errmob.style.color = "red";
            return false;
        }

        else {
            errmob.innerHTML = '';
        }
        // ======================Male OR Female=========================
        if (male.checked == false && fmale.checked == false) {

            errmale.innerHTML = "<b>*Enter Select Any One</b>";
            errmale.style.color = "red";
            return false;
        }
        else {
            errmale.innerHTML = '';
        }


        //======================Languages==================

        if (eng.checked == false && guj.checked == false && hid.checked == false) {
            lang.innerHTML = "Select Any language";
            lang.style.color = "red";

            return false;
        }
        else {
            lang.innerHTML = '';
        }

        // =======================Address =========================

        if (address.value == '') {
            erradd.innerHTML = "Enter Address";
            erradd.style.color = "red";

            return false;
        }
        else {
            erradd.innerHTML = "";
        }
        // ===================images========================

        var extenstion = /(\.jpg|\.jpeg|\.png|\.gif|\.webp)$/i;

        if (img.value == '') {
            errimg.innerHTML = "<b>* Enter upload the File";
            errimg.style.color = "red";

            return false;
        }
        else {
            errimg.innerHTML = '';
        }
        if (!extenstion.exec(img.value)) {
            alert('Invalid file type');
            fileInput.value = '';
            return false;
        }


    }

</script>

<script>
    $('#formdata').on('submit', function (e) {
        e.preventDefault();

        const obj = new FormData(this);

        $.ajax({
            url: "<?php echo e(route('create')); ?>",
            type: 'post',
            data: obj,
            dataType: 'json',
            processData: false,
            contentType: false,
            success: function (res) {
                console.log(res);
                $('#content').html(res);
            }
        })
    })
</script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\php_assessment\assessment_laravel\resources\views/admin/register.blade.php ENDPATH**/ ?>