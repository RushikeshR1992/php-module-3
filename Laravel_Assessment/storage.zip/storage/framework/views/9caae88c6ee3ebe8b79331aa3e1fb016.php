
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Social Welfare</title>
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/global.css" rel="stylesheet">
	<link href="assets/css/index.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css" />
	<link href="https://fonts.googleapis.com/css2?family=Hind:wght@500&display=swap" rel="stylesheet">
	<script src="assets/js/jquery-2.1.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>


  </head>

<body>
<section id="top">
 <div class="container">
  <div class="row">
   <div class="top_1 clearfix">
    <div class="col-sm-7">
	 <div class="top_1l clearfix">
	  <ul class="mgt">
	   <li><i class="fa fa-map-marker"></i> Brooklyn, NY 1XYZ6, United States </li>
	   <li><i class="fa fa-mobile-phone"></i> 1-200-123-4321  </li>
	   <li><i class="fa fa-envelope"></i> <a href="#">info@gmail.com</a> </li>
	  </ul>
	 </div>
	</div>
	<div class="col-sm-5">
	 <div class="top_1r text-right clearfix">
	   <ul class="social-network social-circle mgt">
                        <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="header_top">
 <div class="container">
  <div class="row">
   <div class="header_top_1 clearfix">
    <div class="col-sm-4">
	 <div class="header_top_1l clearfix">
	  <h3 class="bold mgt"><a href="index"><i class="fa fa-heart"></i> <?php echo e(session()->get('name')); ?></a></h3>
	 </div>
	</div>
	<div class="col-sm-8">
	 <div class="header_top_1r clearfix">
	   <ul class="nav navbar-nav navbar-right">
	            <li class="dropdown"><a class="font_tag" href="#" data-toggle="dropdown"><span class="fa fa-search"></span></a>
								<ul class="dropdown-menu drop_2" style="min-width: 300px;">
									<li>
										<div class="row_1">
											<div class="col-sm-12">
												<form class="navbar-form navbar-left" role="search">
												<div class="input-group">
													<input type="text" class="form-control" placeholder="Search">
													<span class="input-group-btn">
														<button class="btn btn-primary" type="button">
															Search</button>
													</span>
												</div>
												</form>
											</div>
										</div>
									</li>
								</ul>
							</li>
				<li><a class="button mgt" href="logoutuser">Logout</a>
                <a class="button mgt" href="<?php echo e(route('Edituser',session()->get('id'))); ?>">Profile Edit</a>
                </li>
			</ul>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="header" class="clearfix">
	 <div class="container">
	  <div class="row">
	   <div class="header clearfix">
		<nav class="navbar">
		<div class="collapse navbar-collapse js-navbar-collapse">
			<ul class="nav navbar-nav">
				<li><a class="m_tag active_tab" href="index">Home</a></li>
				<li><a class="m_tag" href="about">About Us</a></li>
				<li><a class="m_tag" href="blog">Blog</a></li>
				<li><a class="m_tag" href="detail">Detail</a></li>
				<li><a class="m_tag" href="team">Team</a></li>
				<li><a class="m_tag" href="contact">Contact Us</a></li>
				<li class="dropdown">
						  <a class="m_tag" href="#" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown 1 <span class="caret"></span></a>
						  <ul class="dropdown-menu drop_1" role="menu">
							<li><a href="#">Home</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">About Us</a></li>
							<li><a href="#">Detail</a></li>
							<li><a href="#">Team</a></li>
							<li><a href="#">Contact Us</a></li>
						  </ul>
						</li>

			</ul>

		</div><!-- /.nav-collapse -->
	</nav>
	   </div>
	  </div>
	 </div>
    </section>

<section id="header_mini" class="clearfix">
	 <div class="container">
	  <div class="row">
	   <div class="header clearfix">
		<nav class="navbar">
		 <div class="navbar-header">
			<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".js-navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand bold" href="index"><i class="fa fa-heart"></i> Social Welfare</a>
		</div>
		<div class="collapse navbar-collapse js-navbar-collapse">
			<ul class="nav navbar-nav">
				<li><a class="m_tag active_tab" href="index">Home</a></li>
				<li><a class="m_tag" href="about">About Us</a></li>
				<li><a class="m_tag" href="blog">Blog</a></li>
				<li><a class="m_tag" href="detail">Detail</a></li>
				<li><a class="m_tag" href="team">Team</a></li>
				<li><a class="m_tag" href="contact">Contact Us</a></li>
				<li class="dropdown">
						  <a class="m_tag" href="#" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown 1 <span class="caret"></span></a>
						  <ul class="dropdown-menu drop_1" role="menu">
							<li><a href="#">Home</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">About Us</a></li>
							<li><a href="#">Detail</a></li>
							<li><a href="#">Team</a></li>
							<li><a href="#">Contact Us</a></li>
						  </ul>
						</li>
                        <li>
                            <ol><?php echo e(session()->get('name')); ?></ol>
                        </li>
				<li class="dropdown dropdown-large">
				<a href="#" class="dropdown-toggle m_tag" data-toggle="dropdown">Dropdown 2<b class="caret"></b></a>

				<ul class="dropdown-menu dropdown-menu-large row drop_1">
					<li class="col-sm-3">
						<ul>
							<li class="dropdown-header">Glyphicons</li>
							<li><a href="#">Available glyphs</a></li>
							<li class="disabled"><a href="#">How to use</a></li>
							<li><a href="#">Examples</a></li>
							<li class="divider"></li>
							<li class="dropdown-header">Dropdowns</li>
							<li><a href="#">Example</a></li>
							<li><a href="#">Aligninment options</a></li>
							<li><a href="#">Headers</a></li>
							<li><a href="#">Disabled menu items</a></li>
						</ul>
					</li>
					<li class="col-sm-3">
						<ul>
							<li class="dropdown-header">Button groups</li>
							<li><a href="#">Basic example</a></li>
							<li><a href="#">Button toolbar</a></li>
							<li><a href="#">Sizing</a></li>
							<li><a href="#">Nesting</a></li>
							<li><a href="#">Vertical variation</a></li>
							<li class="divider"></li>
							<li class="dropdown-header">Button dropdowns</li>
							<li><a href="#">Single button dropdowns</a></li>
						</ul>
					</li>
					<li class="col-sm-3">
						<ul>
							<li class="dropdown-header">Input groups</li>
							<li><a href="#">Basic example</a></li>
							<li><a href="#">Sizing</a></li>
							<li><a href="#">Checkboxes and radio addons</a></li>
							<li class="divider"></li>
							<li class="dropdown-header">Navs</li>
							<li><a href="#">Tabs</a></li>
							<li><a href="#">Pills</a></li>
							<li><a href="#">Justified</a></li>
						</ul>
					</li>
					<li class="col-sm-3">
						<ul>
							<li class="dropdown-header">Navbar</li>
							<li><a href="#">Default navbar</a></li>
							<li><a href="#">Buttons</a></li>
							<li><a href="#">Text</a></li>
							<li><a href="#">Non-nav links</a></li>
							<li><a href="#">Component alignment</a></li>
							<li><a href="#">Fixed to top</a></li>
							<li><a href="#">Fixed to bottom</a></li>
							<li><a href="#">Static top</a></li>
							<li><a href="#">Inverted navbar</a></li>
						</ul>
					</li>
				</ul>

			</li>

			</ul>

		</div><!-- /.nav-collapse -->
	</nav>
	   </div>
	  </div>
	 </div>
    </section>

    <div class="container pt-5">
    <div class="row justify-content-center">
        <div class="col-xl-6">
            <form action="">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" value="<?php echo e($user->password); ?>" class="form-control">
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\php_assessment\assessment_laravel\resources\views/user/edituser.blade.php ENDPATH**/ ?>