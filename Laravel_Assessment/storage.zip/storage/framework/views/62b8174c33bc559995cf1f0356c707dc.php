<?php $__env->startSection('content'); ?>



<section id="center" class="clearfix center_about">
 <div class="container">
  <div class="row">
   <div class="center_about_1 clearfix">
    <div class="col-sm-6">
	 <div class="center_about_1l clearfix">
	  <h3 class="mgt">Contact Us</h3>
	 </div>
	</div>
	<div class="col-sm-6">
	 <div class="center_about_1r text-center clearfix">
	  <ul class="mgt">
	   <li><a href="#">Home</a></li> /
	   <li>Contact Us</li>
	  </ul>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="contact" class="clearfix">
 <div class="container">
  <div class="row">
      <div class="contact_1 clearfix">
		 <div class="col-sm-12">
		  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d114964.53925916665!2d-80.29949920266738!3d25.782390733064336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88d9b0a20ec8c111%3A0xff96f271ddad4f65!2sMiami%2C+FL%2C+USA!5e0!3m2!1sen!2sin!4v1530774403788" width="100%" height="450px" frameborder="0" style="border:0" allowfullscreen=""></iframe>
		 </div>
	 </div>
	  <div class="contact_2 clearfix">
	   <div class="col-sm-8">
	    <h3 class="bold">Stay In Touch</h3>
		<p>Nulla et tincidunt nunc. Nullam posuere sapien sit amet lorem mollis posuere. Morbi lorem lacus, semper in metus vitae, mattis pharetra mauris. In placerat varius purus, nec scelerisque dolor posuere id. Morbi vulputate sollicitudin quam ac consequat. Integer congue, libero at dignissim vehicula, tellus nisl feugiat eros, quis pretium risus leo eu urna. Nam euismod sapien non ultrices sagittis. Sed at justo quam. Nam tempus, neque eget tempus sollicitudin, lectus quam sagittis eros neque eu quam.</p>
	   </div>
	   <div class="col-sm-4">
	    <ul>
		 <li><i class="fa fa-map-marker"></i> Brooklyn, NY 1XYZ6, United States</li>
		 <li><i class="fa fa-mobile-phone"></i> 1-200-123-4321</li>
		 <li><i class="fa fa-envelope"></i> info@gmail.com</li>
		</ul>
	   </div>
	  </div>
	  <div class="blog_d_page_li3  clearfix">
	     <div class="about_h text-center clearfix">
			 <h3 class="bold mgt">Contact Us</h3>
       </div>
	     <div class="blog_d_page_li3i clearfix">
		  <div class="col-sm-6 space_left">
		   <input class="form-control" type="text" placeholder="Name">
		  </div>
		  <div class="col-sm-6 space_right">
		   <input class="form-control" type="text" placeholder="Email">
		  </div>
		 </div>
		 <div class="blog_d_page_li3i clearfix">
		  <div class="col-sm-6 space_left">
		   <input class="form-control" type="text" placeholder="Website">
		  </div>
		  <div class="col-sm-6 space_right">
		   <input class="form-control" type="text" placeholder="Subject">
		  </div>
		 </div>
		 <div class="blog_d_page_li3i cleafix">
		  <div class="col-sm-12 space_all">
		   <textarea placeholder="Message" class="form-control form_1"></textarea>
		   <h5><a class="button" href="#">Send Message </a></h5>
		  </div>

		 </div>
	   </div>
  </div>
 </div>
</section>

<section id="footer">
  <div class="container">
   <div class="row">
    <div class="footer_1 clearfix">
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">About Us</h3>
	   <hr>
	   <ul>
	    <li><a href="#">About Us</a></li>
		<li><a href="#">Our Team</a></li>
		<li><a href="#">Volunteer Engagement</a></li>
		<li><a href="#">Communications</a></li>
		<li class="border_none"><a href="#">Services</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Discover</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Mission</a></li>
		<li><a href="#">Where We are Headed</a></li>
		<li><a href="#">History</a></li>
		<li><a href="#">Board and Staff</a></li>
		<li class="border_none"><a href="#">Join Our Team</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Support</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Terms of Use</a></li>
		<li><a href="#">Privacy Policy</a></li>
		<li><a href="#">Donor Privacy Policy</a></li>
		<li><a href="#">Internship</a></li>
		<li class="border_none"><a href="#">Copyright Notice</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">News</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Press Room</a></li>
		<li><a href="#">Effectiveness & Results</a></li>
		<li><a href="#">Advisory Panel</a></li>
		<li><a href="#">Endorsements</a></li>
		<li class="border_none"><a href="#">Annual Report</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
	<div class="footer_2 clearfix">
	 <div class="col-sm-6">
	  <div class="footer_2l clearfix">
       <p>© 2013 Your Website Name. All Rights Reserved | Design by <a class="col" href="http://www.templateonweb.com">TemplateOnWeb</a></p>
	  </div>
	 </div>
	 <div class="col-sm-6">
	  <div class="footer_2r clearfix">
       <ul>
	    <li><a href="#">Home</a></li>
		<li><a href="#">What we do</a></li>
		<li><a href="#">About</a></li>
		<li><a href="#">FAQ</a></li>
		<li><a href="#">Get involved</a></li>
		<li><a href="#">Team</a></li>
		<li><a href="#">News</a></li>
		<li><a href="#">Contacts</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
   </div>
  </div>
</section>

<div id="toTop" class="btn btn-info" style="display: block; background:#d43c18; color:#fff; border-color:#d43c18;"><span class="fa fa-chevron-up"></span></div>

<script>
$(document).ready(function(){
  $('body').append('<div id="toTop" class="btn btn-info"><span class="glyphicon glyphicon-chevron-up"></span> Back to Top</div>');
	$(window).scroll(function () {
		if ($(this).scrollTop() != 0) {
			$('#toTop').fadeIn();
		} else {
			$('#toTop').fadeOut();
		}
	});
$('#toTop').click(function(){
	$("html, body").animate({ scrollTop: 0 }, 600);
	return false;
});
});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\php_assessment\assessment_laravel\resources\views/user/contact.blade.php ENDPATH**/ ?>