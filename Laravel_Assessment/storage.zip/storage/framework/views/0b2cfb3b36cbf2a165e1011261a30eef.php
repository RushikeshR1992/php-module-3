<?php $__env->startSection('content'); ?>

<div class="container pt-5">
    <div class="row justify-content-center">
        <div class="col-xl-5">
            <form action="">
                <?php echo csrf_field(); ?>
                <div class="mb-2">
                    <label class="form-label">Name</label>
                    <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control">
                </div><br>
                <!-- <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" value="<?php echo e($user->password); ?>" class="form-control">
                </div> -->
                <div class="mb-3 ">
                    <input type="submit" value="submit" name="submit" class=" btn btn-info ">
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\php_assessment\assessment_laravel\resources\views/user/edit.blade.php ENDPATH**/ ?>