;
<?php $__env->startSection('content'); ?>;

<div class="container pt-5">
    <div class="row justify-content-center">
        <div class="col-xl-6">
            <form action="" id="formid">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label">Notice</label>
                    <textarea class="form-control" name="notify" rows="5" placeholder="PLEASE ENTER ANY NOTICE"></textarea>
                </div>
                <div class="mb-3">
                    <input type="submit" class="btn btn-info" value="submit" id="submit" name="submit">
                </div>
            </form>
        </div>
    </div>
</div>
</div>

<script>
    $('#formid').on('submit',function(e){

        e.preventDefault();
        var formdata = new FormData(this);
        $.ajax({
            url:'<?php echo e(route('store_notice')); ?>',
            type:'post',
            data:formdata,
            dataType:'json',
            processData:false,
            contentType:false,
            success:function (res){
                console.log(res);
            }
        })
   })


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\php_assessment\assessment_laravel\resources\views/admin/add_notice.blade.php ENDPATH**/ ?>