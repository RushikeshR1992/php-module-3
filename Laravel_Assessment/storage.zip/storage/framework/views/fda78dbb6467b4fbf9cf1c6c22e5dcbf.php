<?php $__env->startSection('content'); ?>



<main id="main" class="main">
    <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">



        <!-- Top Selling -->
        <div class="col-15">
            <div class="card top-selling overflow-auto col-12">

                <div class="filter">
                    <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                        <li class="dropdown-header text-start">
                            <h6>Filter</h6>
                        </li>

                        <li><a class="dropdown-item" href="#">Today</a></li>
                        <li><a class="dropdown-item" href="#">This Month</a></li>
                        <li><a class="dropdown-item" href="#">This Year</a></li>
                    </ul>
                </div>

                <div class="card-body pb-0">
                    <h5 class="card-title">Top Selling <span>| Today</span></h5>

                    <div id="table"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- Modal -->
    <div class="modal fade" id="formedit" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Edit Form</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Browser Default Validation -->
                    <form class="row g-3" id="editform" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="col-md-12">
                            <label for="validationDefault01" class="form-label">First name</label>
                            <input type="text" name="id" id="id" hidden>
                            <input type="text" class="form-control" name="name" id="name">
                            <p id="errname"></p>
                        </div>
                        <div class="col-md-12">
                            <label for="validationDefault04" class="form-label">Mobile</label>
                            <input type="number" class="form-control" name="mobile" id="mobile">
                            <p id="errmob"></p>
                        </div>
                        <div class="col-md-12">
                            <label for="validationDefault04" class="form-label">Gender</label>

                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="umale" value="male">
                                <label class="form-check-label">
                                    Male
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="ufmale" value="female">
                                <label class="form-check-label"> Female
                                </label>
                                <p id="errmale"></p>
                            </div>

                            <div class="col-md-12">
                                <label for="validationDefault04" class="form-label">Languges</label>

                                <div class="form-check">
                                    <input class="form-check-input" name="chk[]" type="checkbox" value="English"
                                        id="ueng">
                                    <label class="form-check-label">
                                        English
                                    </label>

                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="chk[]" type="checkbox" value="Gujarati"
                                        id="uguj">
                                    <label class="form-check-label">
                                        Gujarati
                                    </label>

                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="chk[]" type="checkbox" value="Hindi"
                                        id="uhid">
                                    <label class="form-check-label">
                                        Hindi
                                    </label>
                                    <p id="lang"></p>
                                </div>
                            </div>
                            <div class="md-12">
                                <label class="form-label">Address</label>
                                <input type="text" class="form-control" name="address" id="uaddress">
                                <p id="erradd"></p>
                            </div>
                            <div class="col-md-3">
                                <label for="validationDefault04" class="form-label">Images</label>
                                <input type="file" name="uimage" id="uimg">
                                <div id="cimg"></div>
                                <p id="errimg"></p>
                            </div>
                            <div class=" pt-3">
                                <button class="btn btn-primary" type="submit" id="btn" name="submit"
                                    >Submit form</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                    </form>
                    <!-- End Browser Default Validation -->
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Validation Javascript -->
<!-- <script>


    uname = document.getElementById('uname');
    mobile = document.getElementById('umobile');
    male = document.getElementById('umale');
    fmale = document.getElementById('ufmale');
    eng = document.getElementById('eng');
    guj = document.getElementById('guj');
    hid = document.getElementById('hid');
    address = document.getElementById('uaddress');
    img = document.getElementById('img');


    // Err

    errname = document.getElementById('errname');
    errmob = document.getElementById('errmob');
    errmale = document.getElementById('errmale');
    lang = document.getElementById('lang');
    erradd = document.getElementById('erradd');
    errimg = document.getElementById('errimg');

    function validate() {


        //===================== name ==================================
        if (uname.value == '') {
            errname.innerHTML = 'Enter Name';
            errname.style.color = "red";

            return false;
        } else {
            errname.innerText = '';
        }


        // ======================MObile No=========================
        // console.log(mobile.value.length);

        if (mobile.value == '') {
            errmob.innerHTML = "Enter Mobile No";
            errmob.style.color = "red";

            return false;
        }
        else if (mobile.value.length != 10) {
            mobile.value = '';
            errmob.innerHTML = "Enter The Valid Number";
            errmob.style.color = "red";
            return false;
        }

        else {
            errmob.innerHTML = '';
        }
        // ======================Male OR Female=========================
        if (male.checked == false && fmale.checked == false) {

            errmale.innerHTML = "<b>*Enter Select Any One</b>";
            errmale.style.color = "red";
            return false;
        }
        else {
            errmale.innerHTML = '';
        }


        //======================Languages==================

        if (eng.checked == false && guj.checked == false && hid.checked == false) {
            lang.innerHTML = "Select Any language";
            lang.style.color = "red";

            return false;
        }
        else {
            lang.innerHTML = '';
        }

        // =======================Address =========================

        if (address.value == '') {
            erradd.innerHTML = "Enter Address";
            erradd.style.color = "red";

            return false;
        }
        else {
            erradd.innerHTML = "";
        }
        // ===================images========================

        var extenstion = /(\.jpg|\.jpeg|\.png|\.gif|\.webp)$/i;

        if (img.value == '') {
            errimg.innerHTML = "<b>* Enter upload the File";
            errimg.style.color = "red";

            return false;
        }
        else {
            errimg.innerHTML = '';
        }
        if (!extenstion.exec(img.value)) {
            alert('Invalid file type');
            fileInput.value = '';
            return false;
        }


    }

</script> -->

<script>
    function getall() {
        $.ajax({
            url: '<?php echo e(route('view_reg')); ?>',
            type: 'get',
            success: function (res) {
                // console.log(res);
                $('#table').html(res);
            }
        })
    }
    getall();

    $(document).on('click', '.edit', function () {

        id = $(this).attr('id');

        // console.log(id);
        $.ajax({
            url: '<?php echo e(route("reg_edit")); ?>',
            type: 'get',
            data: { id: id },
            success: function (res) {
                console.log(res.name);

                $('#id').val(res.id);
                $('#name').val(res.name);
                $('#email').val(res.email);
                $('#pass').val(res.password);
                $('#mobile').val(res.mobile);

                if (res.gender == 'male') {
                    $('#umale').prop('checked', true);
                } else {
                    $('#umale').prop('checked', false);
                }
                if (res.gender == 'female') {
                    $('#ufmale').prop('checked', true);
                } else {
                    $('#ufmale').prop('checked', true);
                }

                console.log();
                var eng = res.languages.includes('English');
                var guj = res.languages.includes('Gujarati');
                var hid = res.languages.includes('Hindi');

                // English
                if (eng == true) {
                    $('#ueng').prop("checked", true);
                }
                else {
                    $('#ueng').prop("checked", false);
                }

                // Gujarati
                if (guj == true) {
                    $('#uguj').prop("checked", true);
                }
                else {
                    $('#uguj').prop("checked", false);
                }
                //Hindi
                if (hid == true) {
                    $('#uhid').prop("checked", true);
                }
                else {
                    $('#uhid').prop("checked", false);
                }

                // $('#ufmale').val(res.ufmale);
                //
                // $('#uguj').val(res.uguj);
                // $('#uhid').val(res.uhid);

                $('#uaddress').val(res.address);
                $('#cimg').html(`<img src='uploads/${res.images}' width='100px'>`);
            }
        })
    })

    $('#editform').on('submit', function (e) {
        e.preventDefault();

        var JsonData = new FormData(this);

        $.ajax({
            url: '<?php echo e(route('update_reg')); ?>',
            type: 'post',
            data: JsonData,
            dataType: 'json',
            contentType: false,
            processData: false,
            success: function (res) {
                console.log(res);
            }
        })
    })
    /* delete */
    $(document).on('click', '.delete', function () {

        var id = $(this).attr('id');

        $.ajax({
            url: '<?php echo e(route("delete_reg")); ?>',
            method: 'get',
            data: { id: id },
            success: function (res) {
                console.log(res);
            }
        })
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\php_assessment\assessment_laravel\resources\views/admin/view_member.blade.php ENDPATH**/ ?>