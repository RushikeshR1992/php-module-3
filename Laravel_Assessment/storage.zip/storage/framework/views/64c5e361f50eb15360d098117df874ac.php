<?php $__env->startSection('content'); ?>



<main id="main" class="main">
    <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">



        <!-- Top Selling -->
        <div class="col-15">
            <div class="card top-selling overflow-auto col-12">

                <div class="filter">
                    <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                        <li class="dropdown-header text-start">
                            <h6>Filter</h6>
                        </li>

                        <li><a class="dropdown-item" href="#">Today</a></li>
                        <li><a class="dropdown-item" href="#">This Month</a></li>
                        <li><a class="dropdown-item" href="#">This Year</a></li>
                    </ul>
                </div>

                <div class="card-body pb-0">
                    <h5 class="card-title">Top Selling <span>| Today</span></h5>
                    <table id="table"></table>
                </div>
            </div>
        </div>
    </section>
    <!-- Modal -->
    <div class="modal fade" id="editForm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" id="editid">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label">Notice</label>
                            <input type="text" name="id" id="id">
                            <textarea class="form-control" name="notify" id="notice" rows="5"
                                placeholder="PLEASE ENTER ANY NOTICE"></textarea>
                        </div>
                        <div class="mb-3">
                            <input type="submit" name="submit" class="btn btn-info">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        function getall() {

            $.ajax({
                url: '<?php echo e(route('view_notice')); ?>',
                type: 'get',
                success: function (res) {
                    // console.log(res);
                    $('#table').html(res);
                }
            })
        }
        getall();

        $(document).on('click', '.edit', function () {

            var id = $(this).attr('id');
            // console.log(id);

            $.ajax({
                url: '<?php echo e(route('edit_noice')); ?>',
                type: 'get',
                data: { id: id },
                success: function (res) {
                    console.log(res.id);
                    $('#id').val(res.id);
                    $('#notice').val(res.notice);
                }
            })
        })
        $('#editid').on('submit', function (e) {

            e.preventDefault();
            var Formdata = new FormData(this);

            $.ajax({
                url: '<?php echo e(route('update_notice')); ?>',
                type: 'post',
                data: Formdata,
                dataType: 'json',
                processData: false,
                contentType: false,
                success: function (res) {
                    console.log(res);
                    getall();
                    $('#editid').modal('hide');
                }
            })
        })
        $(document).on('click', '.delete', function () {

            var id = $(this).attr('id');

            $.ajax({
                url: '<?php echo e(route('delete_notice')); ?>',
                type: 'get',
                data: { id, id },
                success: function (res) {
                    console.log(res);
                }

            })
        })
        // $(document).on('click', '.delete', function () {

        //     var id = $(this).attr('id');

        //     $.ajax({
        //         url: '<?php echo e(route('delete_watches')); ?>',
        //         type: 'get',
        //         data: { id, id },
        //         success: function (res) {
        //             console.log(res);
        //             getall();
        //         }
        //     })
        // })
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\php_assessment\assessment_laravel\resources\views/admin/view_notice.blade.php ENDPATH**/ ?>