;
<?php $__env->startSection('content'); ?>;

<div class="container">
    <div class="row justify-content-center">
        <div class="col-xl-6">

            <main id="main" class="main">
                <div>
                    <h1>Register Watchman</h1>
                </div>
                <!-- Browser Default Validation -->
                <form class="row g-3" id="formId" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="col-md-12">
                        <label class="form-label">First name</label>
                        <input type="text" class="form-control" name="name" id="uname">
                        <p id="errname"></p>
                    </div>
                    <div class="col-md-12">
                        <label for="validationDefaultUsername" class="form-label">Email</label>
                        <div class="input-group">
                            <span class="input-group-text" id="">@</span>
                            <input type="text" name="email" class="form-control" id="uemail">
                        </div>
                        <p id="erremail"></p>
                    </div>
                    <div class="col-md-12">
                        <label for="validationDefault04" class="form-label">Mobile</label>
                        <input type="text" class="form-control" name="mobile" id="umobile">
                        <p id="errmob"></p>
                    </div>
                    <div class="col-md-12">
                        <label for="validationDefault03" class="form-label">Address</label>
                        <input type="text" class="form-control" name="address" id="uaddress">
                        <p id="erradd"></p>
                    </div>

                    <div class="col-md-3">
                        <label for="validationDefault04" class="form-label">Images</label>
                        <input type="file" name="images" id="img">
                        <p id="errimg"></p>
                    </div>
                    <div class="pt-3">
                        <button class="btn btn-primary" type="submit" id="btn" name="submit"
                            onclick="return validate()">Submit form</button>
                    </div>
                </form>
                <!-- End Browser Default Validation -->


            </main><!-- End #main -->
        </div>
    </div>
</div>

<script>


    uname = document.getElementById('uname');
    email = document.getElementById('uemail');

    mobile = document.getElementById('umobile');

    address = document.getElementById('uaddress');
    img = document.getElementById('img');


    // Err

    errname = document.getElementById('errname');
    erremail = document.getElementById('erremail');

    errmob = document.getElementById('errmob');

    erradd = document.getElementById('erradd');
    errimg = document.getElementById('errimg');

    function validate() {


        //===================== name ==================================
        if (uname.value == '') {
            errname.innerHTML = 'Enter Name';
            errname.style.color = "red";

            return false;
        } else {
            errname.innerText = '';
        }
        //======================== Email =====================================
        if (email.value == '') {
            erremail.innerHTML = "Enter Email";
            erremail.style.color = "red";
            return false;
        }
        else {
            erremail.innerText = '';
        }
        // ======================MObile No=========================
        // console.log(mobile.value.length);

        if (mobile.value == '') {
            errmob.innerHTML = "Enter Mobile No";
            errmob.style.color = "red";

            return false;
        }
        else if (mobile.value.length != 10) {
            mobile.value = '';
            errmob.innerHTML = "Enter The Valid Number";
            errmob.style.color = "red";
            return false;
        }

        else {
            errmob.innerHTML = '';
        }

        // =======================Address =========================

        if (address.value == '') {
            erradd.innerHTML = "Enter Address";
            erradd.style.color = "red";

            return false;
        }
        else {
            erradd.innerHTML = "";
        }
        // ===================images========================

        var extenstion = /(\.jpg|\.jpeg|\.png|\.gif|\.webp)$/i;

        if (img.value == '') {
            errimg.innerHTML = "<b>* Enter upload the File";
            errimg.style.color = "red";

            return false;
        }
        else {
            errimg.innerHTML = '';
        }
        if (!extenstion.exec(img.value)) {
            alert('Invalid file type');
            fileInput.value = '';
            return false;
        }


    }

</script>

<script>

   $('#formId').on('submit',function(e){

        e.preventDefault();
        var formdata = new FormData(this);
        $.ajax({
            url:'<?php echo e(route('store_watchmen')); ?>',
            type:'post',
            data:formdata,
            dataType:'json',
            processData:false,
            contentType:false,
            success:function (res){
                console.log(res);
            }
        })
   })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\php_assessment\assessment_laravel\resources\views/admin/add_watchmen.blade.php ENDPATH**/ ?>