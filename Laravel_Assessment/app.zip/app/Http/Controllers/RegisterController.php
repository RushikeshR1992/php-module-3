<?php

namespace App\Http\Controllers;

use App\Models\events;
use App\Models\notice;
use App\Models\registers;
use App\Models\regwatches;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        return view('admin.register');
    }
    public function admincheck(Request $req)
    {
        // return response()->json($req->email);
        $reg = registers::select()->where('email', '=', $req->email)->first();
        // return response()->json($reg->password);


        if ($reg) {

            if (Hash::check($req->pass, $reg->password)) {


                return response()->json('True');

            } else {

                return response()->json('Wrong');
            }
        } else {
            return response()->json('Wrong Email');
        }
    }

    /**
     * Show the form for creating a new resource.
     */



    /*============= Socity Member Function ===============*/
    public function create(Request $req)
    {
        $user = new registers;
        $user->name = $req->uname;
        $user->email = $req->uemail;
        $user->password = Hash::make($req->upass);
        $user->mobile = $req->umobile;
        $user->gender = $req->ugender;
        // $user->languages = json_encode($req->chk);
        $lan = $req->chk;
        foreach ($lan as $l) {
            $lang = implode(',', $lan);
        }
        $user->languages = $lang;
        $user->address = $req->uaddress;

        if ($req->file('uimage')) {
            $images = $req->uimage;
            $path = "uploads/";
            $file = time() . $images->getClientOriginalName();
            $images->move($path, $file);
            $user->images = $file;
        }
        $user->save();
        return response()->json('sucess');

    }
    public function view_member()
    {
        return view("admin.view_member");
    }
    public function view_reg()
    {
        $var = registers::all();

        $data = "";
        if ($var->count() > 0) {
            $data .= "<table class='table tabel-striped'>
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Gender</th>
                                <th>Languages</th>
                                <th>Address</th>
                                <th>Images</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>";
            foreach ($var as $v) {

                $data .= "<tr>
                                <td>" . $v->id . "</td>
                                <td>" . $v->name . "</td>
                                <td>" . $v->email . "</td>
                                <td>" . $v->mobile . "</td>
                                <td>" . $v->gender . "</td>
                                <td>" . $v->languages . "</td>
                                <td>" . $v->address . "</td>
                                <td><img src='uploads/" . $v->images . "' width='150px'></td>

                                <td><a class='btn btn-primary edit 'id='" . $v->id . "' data-bs-toggle='modal' data-bs-target='#formedit'>Edit</a></td>

                                <td><a id='" . $v->id . "' class='btn btn-danger delete'>Delete</a></td>
                            </tr>";
            }
            $data .= "</tbody>
                    </table>";
        }
        // echo $data;
        return response()->json($data);
    }
    public function reg_edit(Request $request)
    {

        $var = registers::find($request->id);
        return response()->json($var);
    }
    public function update_reg(Request $request)
    {

        $reg = registers::find($request->id);

        if ($request->file('uimage')) {

            $img = $request->uimage;
            $file = time() . $img->getClientOriginalName();
            $img->move(public_path('uploads/'), $file);
        } else {
            $file = $reg->images;
        }
        $reg->name = $request->uname;
        $reg->mobile = $request->umobile;
        $reg->address = $request->address;
        // $lan = $req->chk;
        $lan = $request->chk;
        foreach ($lan as $l) {
            $lang = implode(',', $lan);
        }
        $reg->languages = $lang;
        $reg->images = $file;


        $reg->update();

        return response()->json('success');
    }
    public function delete_reg(Request $request)
    {

        $var = registers::find($request->id);
        $var->delete();
        return response()->json('delete');
    }
    public function dashboard()
    {
        return view('admin.dashboard');
    }
    public function login()
    {
        return view('index');
    }

    public function profile()
    {
        return view('admin.profile');
    }
    public function adminlogin()
    {
        return view('admin.adminlogin');
    }
    public function adminindex()
    {
        return view('admin.index');
    }


    /*============= Socity WatchMen Function ===============*/


    public function add_watchmen()
    {
        return view('admin.add_watchmen');
    }
    public function store_watchmen(Request $request)
    {
        $reg = new regwatches();

        if ($request->file('images')) {
            $img = $request->images;
            $file = time() . $img->getClientOriginalName();
            $img->move(public_path('uploads/'), $file);
        }
        $reg->name = $request->name;
        $reg->email = $request->email;
        $reg->mobile = $request->mobile;
        $reg->address = $request->address;
        $reg->images = $file;

        $reg->save();
        return response()->json('success');
    }
    public function show_watch()
    {
        return view('admin.view_watchmen');
    }
    public function view_watchmen()
    {
        $var = regwatches::all();

        $data = "";

        if ($var->count() > 0) {

            $data .= "<table class='table tabel-striped'>
                            <thead>
                                <tr>
                                    <td>id</td>
                                    <td>name</td>
                                    <td>email</td>
                                    <td>mobile</td>
                                    <td>address</td>
                                    <td>images</td>
                                    <td>Action</td>
                                </tr>
                            </thead>
                            <tbody>";
            foreach ($var as $r) {
                $data .= "<tr>
                                    <td>" . $r->id . "</td>
                                    <td>" . $r->name . "</td>
                                    <td>" . $r->email . "</td>
                                    <td>" . $r->mobile . "</td>
                                    <td>" . $r->address . "</td>
                                    <td><img src='uploads/" . $r->images . "'width='100px'></td>

                                    <td><a class='btn btn-primary edit' id='" . $r->id . "' data-bs-toggle='modal' data-bs-target='#editForm'>Edit</a>


                                    <a id='" . $r->id . "' class='btn btn-danger delete'>Delete</a></td>

                                </tr>";
            }
            $data .= "</tbody>
                        </table>";
        }
        return response()->json($data);
    }
    public function edit_watch(Request $request)
    {
        $var = regwatches::find($request->id);
        return response()->json($var);
    }

    public function update_watch(Request $request)
    {

        $var = regwatches::find($request->id);

        if ($request->file('images')) {

            $img = $request->images;
            // $file= time().$img->getClientOriginalExtension();
            $file = time() . $img->getClientOriginalName();
            $img->move(public_path('uploads/'), $file);
        } else {
            $file = $var->images;
        }
        $var->name = $request->name;
        $var->email = $request->email;
        $var->mobile = $request->mobile;
        $var->address = $request->address;
        $var->images = $file;

        $var->update();

        return response()->json('Updated');
    }
    public function delete_fun(Request $request)
    {
        $var = regwatches::find($request->id);

        $var->delete();
        return response()->json('var');

    }

    /*============= Socity Notice Function ===============*/

    public function add_notice()
    {
        return view('admin.add_notice');
    }
    public function store_notice(Request $request)
    {

        $reg = new notice();
        $reg->notice = $request->notify;
        $reg->save();
        return response()->json('success');
    }
    public function show_notice()
    {
        return view('admin.view_notice');
    }
    public function view_notice()
    {
        $var = notice::all();

        $data = "";

        if ($var->count() > 0) {

            $data .= "<table class='table tabel-striped'>
                        <thead>
                            <tr>
                                <td>id</td>
                                <td>notice</td>
                            </tr>
                        </thead>
                        <tbody>";
            foreach ($var as $r) {
                $data .= "<tr>
                                <td>" . $r->id . "</td>
                                <td>" . $r->notice . "</td>

                                <td><a class='btn btn-primary edit' id='" . $r->id . "' data-bs-toggle='modal' data-bs-target='#editForm'>Edit</a>


                                <a id='" . $r->id . "' class='btn btn-danger delete'>Delete</a></td>

                            </tr>";
            }
            $data .= "</tbody>
                    </table>";
        }
        echo $data;
        // return response()->json($data);
    }
    public function edit_noice(Request $request)
    {

        $var = notice::find($request->id);
        return response()->json($var);
    }
    public function update_notice(Request $request)
    {

        $var = notice::find($request->id);

        $var->notice = $request->notify;

        $var->update();

        return response()->json('Updated');
    }
    public function delete_notice(Request $request)
    {
        $var = notice::find($request->id);

        $var->delete();
        return response()->json('deleted');
    }
    /*============= Socity Events Function ===============*/
    public function add_event()
    {
        return view('admin.add_event');
    }
    public function store_event(Request $request)
    {

        $var = new events();

        if ($request->file('images')) {
            $img = $request->images;
            $file = time() . $img->getClientOriginalName();
            $img->move(public_path('uploads/'), $file);
        }
        $var->images = $file;
        $var->save();
        return response()->json('success');
    }
    public function show_event()
    {
        return view('admin.view_event');
    }

    public function view_event(Request $request)
    {

        $var = events::all();

        $data = "";

        if ($var->count() > 0) {

            $data = "<table class='table tabel-striped'>
                        <tr>
                            <td>ID<td>
                            <td>Images<td>
                            <td>Action</td>
                        <tr>
                    <table>
                    <tbody>";
            foreach ($var as $r) {
                $data .= "<tr>
                                <td>" . $r->id . "</td>
                                <td><img src='uploads/" . $r->images . "' alt='pending' width='100px'></td>

                                <td><a class='btn btn-primary edit' id='" . $r->id . "' data-bs-toggle='modal' data-bs-target='#modaledit'>Edit</a></td>

                                <td><a id='" . $r->id . "' class='btn btn-danger delete'>Delete</a></td>
                            </tr>";
            }
            $data .= "</tbody>
                        </table>";
        }

        return response()->json($data);
    }
    public function edit_events(Request $request)
    {

        $var = events::find($request->id);
        return response()->json($var);
    }
    public function update_events(Request $request)
    {
        $var = events::find($request->id);

        if ($request->file('images')) {

            $img = $request->images;
            $file = time() . $img->getClientOriginalName();
            $img->move(public_path('uploads/'), $file);
        } else {
            $file = $var->images;
        }

        $var->images = $file;

        $var->update();

        return response()->json('Updated');
    }
    public function delete_events(Request $request){

       $del = events::find($request->id);
       $del->delete();
       return response()->json('deleted');
    }

}
