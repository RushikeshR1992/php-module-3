<?php

namespace App\Http\Controllers;

use App\Models\registers;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;

class ReguserController extends Controller
{
    public function usercheck(Request $request){
        // return response()->json($request->email);
        // $reg= registers::select()->where('email','=',$request->email)->first();
        // return response()->json($reg->pass);

        $reg = registers::select()->where('email','=',$request->email)->first();
        if($reg){

            if(Hash::check($request->pass,$reg->password)){

                session()->put('name',$reg->name);
                session()->put('id',$reg->id);

                return response()->json('true');
            }
            else{
                return response()->json('Wrong');
            }
        }
        else{
            return response()->json('Wrong Email');
        }
    }
    public function index(){
        return view('user.index');
    }
    public function about(){
        return view('user.about');
    }
    public function blog(){
        return view('user.blog');
    }
    public function contact(){
        return view('user.contact');
    }
    public function detail(){
        return view('user.detail');
    }
    public function team(){

        return view('user.team');
    }
    public function logoutuser(){

            session()->pull('name');
            session()->pull('id'); //sesstion END

        return view('index');
    }
    public function Edituser(){
        $id = session()->get('id');
        // echo $id;
        $user = registers::find($id);
        // $user = User::select()->where('id','=',$id)->first();
        // $user = DB::table('users')->where('id','=',$id)->first();
        // $user = User::where('id', $id)->first();

        // echo $user;
    return view('user.edit',compact('user'));
    // print_r($user);
}
}
