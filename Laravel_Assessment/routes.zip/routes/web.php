<?php

use App\Http\Controllers\RegisterController;
use App\Http\Controllers\ReguserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/practice', function () {
//     return view('practice');
// });

// ADMIN PANEL
Route::post("/create",[RegisterController::class,'create'])->name('create');
Route::get("/dashboard",[RegisterController::class,'dashboard'])->name('dashboard');
Route::get("/",[RegisterController::class,'login'])->name('login');
Route::get("/store",[RegisterController::class,'store'])->name('store');
Route::get("/adminlogin",[RegisterController::class,'adminlogin'])->name('adminlogin');
Route::get("/admincheck",[RegisterController::class,'admincheck'])->name('admincheck');
Route::get("/adminindex",[RegisterController::class,'adminindex'])->name('adminindex');



// member registers
Route::get("/register",[RegisterController::class,'index'])->name('register');
Route::get("/view_member",[RegisterController::class,'view_member'])->name('view_member');
Route::get("/view_reg",[RegisterController::class,'view_reg'])->name('view_reg');
Route::get('/reg_edit',[RegisterController::class,'reg_edit'])->name('reg_edit');
Route::post('/update_reg',[RegisterController::class,'update_reg'])->name('update_reg');
Route::get('/delete_reg',[RegisterController::class,'delete_reg'])->name('delete_reg');

// watchman_profiles
Route::get('/add_watchmen',[RegisterController::class,'add_watchmen'])->name('add_watchmen');
Route::post('/store_watchmen',[RegisterController::class,'store_watchmen'])->name('store_watchmen');
Route::get('/show_watch',[RegisterController::class,'show_watch'])->name('show_watch');
Route::get('/view_watchmen',[RegisterController::class,'view_watchmen'])->name('view_watchmen');
Route::get('/edit_watch',[RegisterController::class,'edit_watch'])->name('edit_watch');
Route::post('/update_watch',[RegisterController::class,'update_watch'])->name('update_watch');
Route::get('/delete_watches',[RegisterController::class,'delete_watches'])->name('delete_watches');

// Notice_profiles
Route::get('/add_notice',[RegisterController::class,'add_notice'])->name('add_notice');
Route::post('/store_notice',[RegisterController::class,'store_notice'])->name('store_notice');
Route::get('/view_notice',[RegisterController::class,'view_notice'])->name('view_notice');
Route::get('/show_notice',[RegisterController::class,'show_notice'])->name('show_notice');
Route::get('/edit_noice',[RegisterController::class,'edit_noice'])->name('edit_noice');
Route::post('/update_notice',[RegisterController::class,'update_notice'])->name('update_notice');
Route::get('/delete_notice',[RegisterController::class,'delete_notice'])->name('delete_notice');


// event_profiles
Route::get('/add_event',[RegisterController::class,'add_event'])->name('add_event');
Route::post('/store_event',[RegisterController::class,'store_event'])->name('store_event');
Route::get('/show_event',[RegisterController::class,'show_event'])->name('show_event');
Route::get('/view_event',[RegisterController::class,'view_event'])->name('view_event');
Route::get('/edit_events',[RegisterController::class,'edit_events'])->name('edit_events');
Route::post('/update_events',[RegisterController::class,'update_events'])->name('update_events');
Route::delete('/delete_events',[RegisterController::class,'delete_events'])->name('delete_events');


//USER Penal
Route::get('/usercheck',[ReguserController::class,'usercheck'])->name('usercheck');
Route::get('/index',[ReguserController::class,'index'])->name('index');
Route::get('/about',[ReguserController::class,'about'])->name('about');
Route::get('/blog',[ReguserController::class,'blog'])->name('blog');
Route::get('/contact',[ReguserController::class,'contact'])->name('contact');
Route::get('/detail',[ReguserController::class,'detail'])->name('detail');
Route::get('/team',[ReguserController::class,'team'])->name('team');
Route::get('/logoutuser',[ReguserController::class,'logoutuser'])->name('logoutuser');
Route::get('/Edituser',[ReguserController::class,'Edituser'])->name('Edituser');





