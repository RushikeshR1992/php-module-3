@extends('user.master')
@section('content')

<div class="container pt-5">
    <div class="row justify-content-center">
        <div class="col-xl-5">
            <form action="">
                @csrf
                <div class="mb-2">
                    <label class="form-label">Name</label>
                    <input type="text" name="name" value="{{$user->name}}" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" value="{{$user->email}}" class="form-control">
                </div><br>
                <!-- <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" value="{{$user->password}}" class="form-control">
                </div> -->
                <div class="mb-3 ">
                    <input type="submit" value="submit" name="submit" class=" btn btn-info ">
                </div>
            </form>
        </div>
    </div>
</div>

@endsection
