@extends('user.master')
@section('content')



<section id="center" class="clearfix center_home">
	 <div class="center clearfix">
		   <div id="carousel" class="carousel slide carousel-fade">
				<!-- Carousel items -->
				<div class="carousel-inner">
				  <div data-slide-no="0" class="item carousel-item">
					<img src="img/images2.png" alt="">

				  </div>
				  <div data-slide-no="1" class="item carousel-item active">
					<img src="img/imges_1.png" alt="">

				  </div>
				  <div data-slide-no="2" class="item carousel-item">
					<img src="img/images3.png" alt="">

				  </div>
				</div>
				<!-- Carousel nav -->				<a class="carousel-control left" href="#carousel" data-slide="prev">‹</a>
				<a class="carousel-control right" href="#carousel" data-slide="next"></a>
			  </div>
		 </div>
   </section>

<section id="progress">
 <div class="container">
  <div class="row">
   <div class="progress_1 clearfix">
    <div class="col-sm-3">
	 <div class="progress_1i text-center clearfix">
	  <span><i class="fa fa-shield"></i></span>
	  <h3 class="bold">Mission</h3>
	  <p>Accusantium quam, ultricies eget tempor id, aliquam eget nibh et. Maecen aliquam, risus at semper ullamcorper, magna</p>
	  <h5 class="mgt"><a class="button_1" href="#">Read more</a></h5>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="progress_1i text-center clearfix">
	  <span><i class="fa fa-users"></i></span>
	  <h3 class="bold">Events</h3>
	  <p>Accusantium quam, ultricies eget tempor id, aliquam eget nibh et. Maecen aliquam, risus at semper ullamcorper, magna</p>
	  <h5 class="mgt"><a class="button_1" href="#">Read more</a></h5>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="progress_1i text-center clearfix">
	  <span><i class="fa fa-headphones"></i></span>
	  <h3 class="bold">Support</h3>
	  <p>Accusantium quam, ultricies eget tempor id, aliquam eget nibh et. Maecen aliquam, risus at semper ullamcorper, magna</p>
	  <h5 class="mgt"><a class="button_1" href="#">Read more</a></h5>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="progress_1i text-center clearfix">
	  <span><i class="fa fa-user-plus"></i></span>
	  <h3 class="bold">Volunteer</h3>
	  <p>Accusantium quam, ultricies eget tempor id, aliquam eget nibh et. Maecen aliquam, risus at semper ullamcorper, magna</p>
	  <h5 class="mgt"><a class="button_1" href="#">Read more</a></h5>
	 </div>
	</div>
   </div>
   <div class="progress_2 clearfix">
    <div class="col-sm-4 space_left">
	 <div class="progress_2i clearfix">
	  <img src="img/4.jpg" class="iw" alt="abc">
	 </div>
	</div>
	<div class="col-sm-5">
	 <div class="progress_2i1 clearfix">
	  <h5 class="mgt">$1965 To Go</h5>
	  <h3><a href="#">Sponsor an Orphan Child‎</a></h3>
	  <p>Volunteering is generally considered an altruistic activity and is intended to promote goodness or improve human quality of life. In return, this activity can produce a feeling of self-worth and respect. There is no financial gain involved for the individual. Volunteering is also renowned for skill development, socialization, and fun.</p>
	  <h5><a class="button" href="#">Donate Now</a></h5>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="progress_2i2 clearfix">
	   <div class="progress clearfix yellow">
                <span class="progress-left">
                    <span class="progress-bar"></span>
                </span>
                <span class="progress-right">
                    <span class="progress-bar"></span>
                </span>
                <div class="progress-value">75%</div>
            </div>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="cause">
 <div class="container">
  <div class="row">
   <div class="cause_1 clearfix">
      <div class="col-sm-6">
	 <div class="cause_1_l clearfix">
	  <h2 class="mgt">Cause List</h2>
	 </div>
	</div>
	  <div class="col-sm-6">
	 <div class="cause_1_r clearfix">
	   <div class="controls clearfix pull-right">
                    <a class="left fa fa-chevron-left btn btn-success" href="#carousel-example" data-slide="prev"></a><a class="right fa fa-chevron-right btn btn-success" href="#carousel-example" data-slide="next"></a>
                </div>
	 </div>
	</div>
   </div>
   <div id="carousel-example" class="carousel slide cause_2" data-ride="carousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item active">
                    <div class="col-sm-3">
                      <div class="cause_2i clearfix">
					   <div  class="cause_2ii clearfix">
					    <img src="img/5.jpg" alt="abc" class="iw">
					   </div>
					   <div  class="cause_2ii1 clearfix">
					    <span><i class="fa fa-folder"></i></span>
					   </div>

					   </div>
					  <div class="cause_2i1 clearfix">
					   <h4 class="bold"><a href="#">Proper Elderly Care</a></h4>
					   <p>Volunteering is generally considered an altruistic activity and is intended to promote goodness or improve human quality of life. </p>
					  </div>
					  <div class="cause_2i2 clearfix">
	                   <h5>Donated <span class="pull-right">90%</span></h5>
						   <div class="progress">
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 90%">
								</div>
							</div>
	                  </div>
                    </div>
					<div class="col-sm-3">
                      <div class="cause_2i clearfix">
					   <div  class="cause_2ii clearfix">
					    <img src="img/6.jpg" alt="abc" class="iw">
					   </div>
					   <div  class="cause_2ii1 clearfix">
					    <span><i class="fa fa-folder"></i></span>
					   </div>

					   </div>
					  <div class="cause_2i1 clearfix">
					   <h4 class="bold"><a href="#">Proper Elderly Care</a></h4>
					   <p>Volunteering is generally considered an altruistic activity and is intended to promote goodness or improve human quality of life. </p>
					  </div>
					  <div class="cause_2i2 clearfix">
	                   <h5>Donated <span class="pull-right">80%</span></h5>
						   <div class="progress">
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
								</div>
							</div>
	                  </div>
                    </div>
					<div class="col-sm-3">
                      <div class="cause_2i clearfix">
					   <div  class="cause_2ii clearfix">
					    <img src="img/7.jpg" alt="abc" class="iw">
					   </div>
					   <div  class="cause_2ii1 clearfix">
					    <span><i class="fa fa-folder"></i></span>
					   </div>

					   </div>
					  <div class="cause_2i1 clearfix">
					   <h4 class="bold"><a href="#">Proper Elderly Care</a></h4>
					   <p>Volunteering is generally considered an altruistic activity and is intended to promote goodness or improve human quality of life. </p>
					  </div>
					  <div class="cause_2i2 clearfix">
	                   <h5>Donated <span class="pull-right">75%</span></h5>
						   <div class="progress">
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 75%">
								</div>
							</div>
	                  </div>
                    </div>
					<div class="col-sm-3">
                      <div class="cause_2i clearfix">
					   <div  class="cause_2ii clearfix">
					    <img src="img/8.jpg" alt="abc" class="iw">
					   </div>
					   <div  class="cause_2ii1 clearfix">
					    <span><i class="fa fa-folder"></i></span>
					   </div>

					   </div>
					  <div class="cause_2i1 clearfix">
					   <h4 class="bold"><a href="#">Proper Elderly Care</a></h4>
					   <p>Volunteering is generally considered an altruistic activity and is intended to promote goodness or improve human quality of life. </p>
					  </div>
					  <div class="cause_2i2 clearfix">
	                   <h5>Donated <span class="pull-right">60%</span></h5>
						   <div class="progress">
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
								</div>
							</div>
	                  </div>
                    </div>
                </div>
                <div class="item">
                    <div class="col-sm-3">
                      <div class="cause_2i clearfix">
					   <div  class="cause_2ii clearfix">
					    <img src="img/9.jpg" alt="abc" class="iw">
					   </div>
					   <div  class="cause_2ii1 clearfix">
					    <span><i class="fa fa-folder"></i></span>
					   </div>

					   </div>
					  <div class="cause_2i1 clearfix">
					   <h4 class="bold"><a href="#">Proper Elderly Care</a></h4>
					   <p>Volunteering is generally considered an altruistic activity and is intended to promote goodness or improve human quality of life. </p>
					  </div>
					  <div class="cause_2i2 clearfix">
	                   <h5>Donated <span class="pull-right">50%</span></h5>
						   <div class="progress">
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
								</div>
							</div>
	                  </div>
                    </div>
					<div class="col-sm-3">
                      <div class="cause_2i clearfix">
					   <div  class="cause_2ii clearfix">
					    <img src="img/10.jpg" alt="abc" class="iw">
					   </div>
					   <div  class="cause_2ii1 clearfix">
					    <span><i class="fa fa-folder"></i></span>
					   </div>

					   </div>
					  <div class="cause_2i1 clearfix">
					   <h4 class="bold"><a href="#">Proper Elderly Care</a></h4>
					   <p>Volunteering is generally considered an altruistic activity and is intended to promote goodness or improve human quality of life. </p>
					  </div>
					  <div class="cause_2i2 clearfix">
	                   <h5>Donated <span class="pull-right">45%</span></h5>
						   <div class="progress">
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 45%">
								</div>
							</div>
	                  </div>
                    </div>
					<div class="col-sm-3">
                      <div class="cause_2i clearfix">
					   <div  class="cause_2ii clearfix">
					    <img src="img/11.jpg" alt="abc" class="iw">
					   </div>
					   <div  class="cause_2ii1 clearfix">
					    <span><i class="fa fa-folder"></i></span>
					   </div>

					   </div>
					  <div class="cause_2i1 clearfix">
					   <h4 class="bold"><a href="#">Proper Elderly Care</a></h4>
					   <p>Volunteering is generally considered an altruistic activity and is intended to promote goodness or improve human quality of life. </p>
					  </div>
					  <div class="cause_2i2 clearfix">
	                   <h5>Donated <span class="pull-right">30%</span></h5>
						   <div class="progress">
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 30%">
								</div>
							</div>
	                  </div>
                    </div>
					<div class="col-sm-3">
                      <div class="cause_2i clearfix">
					   <div  class="cause_2ii clearfix">
					    <img src="img/12.jpg" alt="abc" class="iw">
					   </div>
					   <div  class="cause_2ii1 clearfix">
					    <span><i class="fa fa-folder"></i></span>
					   </div>

					   </div>
					  <div class="cause_2i1 clearfix">
					   <h4 class="bold"><a href="#">Proper Elderly Care</a></h4>
					   <p>Volunteering is generally considered an altruistic activity and is intended to promote goodness or improve human quality of life. </p>
					  </div>
					  <div class="cause_2i2 clearfix">
	                   <h5>Donated <span class="pull-right">95%</span></h5>
						   <div class="progress">
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 95%">
								</div>
							</div>
	                  </div>
                    </div>
                </div>
            </div>
        </div>
  </div>
 </div>
</section>

<section id="event_home">
 <div class="container">
  <div class="row">
   <div class="event_h1 clearfix">
    <div class="col-sm-6">
	 <div class="event_h1l clearfix">
	  <div class="event_h1li clearfix">
	   <h3 class="mgt">Events List</h3>
	  </div>
	  <div class="event_h1li1 clearfix">
	   <div class="col-sm-3 space_left">
	    <div class="event_h1li1l clearfix">
		 <hr>
		 <h3 class="mgt">05 <span>April</span></h3>
		</div>
	   </div>
	   <div class="col-sm-9">
	    <div class="event_h1li1r clearfix">
		 <h4 class="mgt bold"><a href="#">Workshop by Bob Doe</a></h4>
		 <h6><i class="fa fa-clock-o"></i> April 3, 2020 / 8:00 am - April 6, 2021 / 5:00 pm</h6>
		 <h6><i class="fa fa-map-marker"></i> Baltimore MD United States</h6>
		</div>
	   </div>
	  </div>
	  <div class="event_h1li1 clearfix">
	   <div class="col-sm-3 space_left">
	    <div class="event_h1li1l clearfix">
		 <hr>
		 <h3 class="mgt">08 <span>April</span></h3>
		</div>
	   </div>
	   <div class="col-sm-9">
	    <div class="event_h1li1r clearfix">
		 <h4 class="mgt bold"><a href="#">Annual Charity Dinner</a></h4>
		 <h6><i class="fa fa-clock-o"></i> April 3, 2020 / 8:00 am - April 6, 2021 / 5:00 pm</h6>
		 <h6><i class="fa fa-map-marker"></i> Baltimore MD United States</h6>
		</div>
	   </div>
	  </div>
	  <div class="event_h1li1 clearfix">
	   <div class="col-sm-3 space_left">
	    <div class="event_h1li1l clearfix">
		 <hr>
		 <h3 class="mgt">09 <span>April</span></h3>
		</div>
	   </div>
	   <div class="col-sm-9">
	    <div class="event_h1li1r clearfix">
		 <h4 class="mgt bold"><a href="#">Initial Volunteer Briefing</a></h4>
		 <h6><i class="fa fa-clock-o"></i> April 3, 2020 / 8:00 am - April 6, 2021 / 5:00 pm</h6>
		 <h6><i class="fa fa-map-marker"></i> Baltimore MD United States</h6>
		</div>
	   </div>
	  </div>
	  <div class="event_h1li2 clearfix">
	   <h5><a class="col_1" href="#">View More…</a></h5>
	  </div>
	 </div>
	</div>
	<div class="col-sm-6">
	 <div class="event_h1r clearfix">
	  <div class="event_h1r1 clearfix">
	    <h3 class="mgt">Short Information</h3>
	  </div>
	  <div class="event_h1r2 clearfix">
	   <div class="col-sm-12">
		  <ul class="mgt">
		  <li class="active"><a data-toggle="tab" href="#home">Event</a></li>
		  <li><a data-toggle="tab" href="#menu1">Press</a></li>
		</ul>
	   </div>
      </div>
      <div class="event_h1r3 clearfix">
			<div class="tab-content clearfix">
			  <div id="home" class="tab-pane fade in active clearfix">
				 <div class="click clearfix">
		          <div class="home_i col-sm-12 clearfix">
				   <h4 class="mgt bold">Hooray!</h4>
				   <p>Aras nec imperdiet neque. Vestibulum sem libero, ultrices sit amet elit at, aliquet accumsan purus. Suspendisse interdum felis at odio molestie, at elementum nisi dictum. Donec ac ultricies nisl. Nam posuere accumsan diam, vel mattis nibh volutpat hendrerit. Curabitur ultrices auctor nisl, vel ultricies massa euismod sed. Etiam at imperdiet nulla.</p>
				  </div>
				 </div>
			  </div>
			  <div id="menu1" class="tab-pane fade clearfix">
				 <div class="click clearfix">
				   <div class="home_i col-sm-12 clearfix">
				   <h4 class="mgt bold">Jobs for disabled people</h4>
				   <p>Etiam eu molestie eros, commodo hendrerit sapien. Maecenas tempus leo ac nisi iaculis porta. Sed sapien tortor, aliquet a velit ut, lacinia molestie velit. Maecenas ornare consequat massa ullamcorper dapibus. Aliquam auctor, sapien sit amet accumsan facilisis, enim enim aliquet arcu, tincidunt pellentesque justo turpis id neque. Duis eleifend nunc sit amet mi dapibus ornare. Suspendisse vel libero sem.</p>
				   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices ipsum non mattis pharetra. Integer laoreet non felis sit amet pharetra. Integer mollis eget felis non finibus.</p>
				  </div>

				 </div>
			  </div>
			  <div id="menu2" class="tab-pane fade clearfix">
				 <div class="click clearfix">
				   <div class="home_i col-sm-12 clearfix">
				    <a href="#"><img src="img/13.jpg" class="iw" alt="abc"></a>
				  </div>
				 </div>
			  </div>
            </div>
		</div>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>



<section id="news_home">
 <div class="container">
  <div class="row">
   <div class="news_home_1 text-center clearfix">
    <div class="col-sm-12">
	  <h2 class="mgt">Latest News</h2>
	</div>
   </div>
   <div class="news_home_2 clearfix">
    <div class="col-sm-3 space_all">
	 <div class="news_home_2l clearfix">
	  <div class="news_home_2li clearfix">
	   <a href="#"><img src="img/15.jpg" alt="abc" class="iw"></a>
	  </div>
	  <a href="#"><div class="news_home_2li1 clearfix"></div></a>
	 </div>
	</div>
	<div class="col-sm-3 space_all">
	 <div class="news_home_2r clearfix">
	  <h6 class="mgt tc">On May 29, 2014</h6>
	  <h5 class="bold"><a href="#">Donate to support the cause</a></h5>
	  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
	  <h6>By <a class="col_1" href="#">Semper Porta <span class="pull-right">0 <i class="fa fa-comment-o"></i></span></a></h6>
	  <h6>In <a class="col_1" href="#">News <span class="pull-right">24 <i class="fa fa-heart-o"></i></span></a></h6>
	 </div>
	</div>
	<div class="col-sm-3 space_all">
	 <div class="news_home_2l clearfix">
	  <div class="news_home_2li clearfix">
	   <a href="#"><img src="img/16.jpg" alt="abc" class="iw"></a>
	  </div>
	  <a href="#"><div class="news_home_2li1 clearfix"></div></a>
	 </div>
	</div>
	<div class="col-sm-3 space_all">
	 <div class="news_home_2r clearfix">
	  <h6 class="mgt tc">On May 29, 2014</h6>
	  <h5 class="bold"><a href="#">Donate to support the cause</a></h5>
	  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
	  <h6>By <a class="col_1" href="#">Semper Porta <span class="pull-right">0 <i class="fa fa-comment-o"></i></span></a></h6>
	  <h6>In <a class="col_1" href="#">News <span class="pull-right">24 <i class="fa fa-heart-o"></i></span></a></h6>
	 </div>
	</div>
   </div>
   <div class="news_home_2 clearfix">
    <div class="col-sm-3 space_all">
	 <div class="news_home_2r clearfix">
	  <h6 class="mgt tc">On May 29, 2014</h6>
	  <h5 class="bold"><a href="#">Donate to support the cause</a></h5>
	  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
	  <h6>By <a class="col_1" href="#">Semper Porta <span class="pull-right">0 <i class="fa fa-comment-o"></i></span></a></h6>
	  <h6>In <a class="col_1" href="#">News <span class="pull-right">24 <i class="fa fa-heart-o"></i></span></a></h6>
	 </div>
	</div>
    <div class="col-sm-3 space_all">
	 <div class="news_home_2l clearfix">
	  <div class="news_home_2li clearfix">
	   <a href="#"><img src="img/17.jpg" alt="abc" class="iw"></a>
	  </div>
	  <a href="#"><div class="news_home_2li1 clearfix"></div></a>
	 </div>
	</div>
	<div class="col-sm-3 space_all">
	 <div class="news_home_2r clearfix">
	  <h6 class="mgt tc">On May 29, 2014</h6>
	  <h5 class="bold"><a href="#">Donate to support the cause</a></h5>
	  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
	  <h6>By <a class="col_1" href="#">Semper Porta <span class="pull-right">0 <i class="fa fa-comment-o"></i></span></a></h6>
	  <h6>In <a class="col_1" href="#">News <span class="pull-right">24 <i class="fa fa-heart-o"></i></span></a></h6>
	 </div>
	</div>
	<div class="col-sm-3 space_all">
	 <div class="news_home_2l clearfix">
	  <div class="news_home_2li clearfix">
	   <a href="#"><img src="img/18.jpg" alt="abc" class="iw"></a>
	  </div>
	  <a href="#"><div class="news_home_2li1 clearfix"></div></a>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="custom">
 <div class="container">
  <div class="row">
   <div class="news_home_1 text-center clearfix">
    <div class="col-sm-12">
	  <h2 class="mgt">Our Donators</h2>
	</div>
   </div>
   <div class="custom_1 clearfix">
    <div class="col-sm-3">
	 <div class="custom_1i clearfix">
	  <a href="#"><img src="img/19.jpg" alt="abc" class="iw"></a>
	 </div>
	 <div class="custom_1i1 clearfix">
	  <h4 class="bold"><a href="#">Semper Porta</a></h4>
	  <h5>Support Military Families</h5>
	 </div>
	 <div class="custom_1i2 clearfix">
	  <h6>Donated<span class="pull-right col_1 bold">$12300</span></h6>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="custom_1i clearfix">
	  <a href="#"><img src="img/20.jpg" alt="abc" class="iw"></a>
	 </div>
	 <div class="custom_1i1 clearfix">
	  <h4 class="bold"><a href="#">Mauris Massa</a></h4>
	  <h5>Support Military Families</h5>
	 </div>
	 <div class="custom_1i2 clearfix">
	  <h6>Donated<span class="pull-right col_1 bold">$12300</span></h6>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="custom_1i clearfix">
	  <a href="#"><img src="img/21.jpg" alt="abc" class="iw"></a>
	 </div>
	 <div class="custom_1i1 clearfix">
	  <h4 class="bold"><a href="#">Lacinia Arcu</a></h4>
	  <h5>Support Military Families</h5>
	 </div>
	 <div class="custom_1i2 clearfix">
	  <h6>Donated<span class="pull-right col_1 bold">$12300</span></h6>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="custom_1i clearfix">
	  <a href="#"><img src="img/22.jpg" alt="abc" class="iw"></a>
	 </div>
	 <div class="custom_1i1 clearfix">
	  <h4 class="bold"><a href="#">Eget Nulla</a></h4>
	  <h5>Support Military Families</h5>
	 </div>
	 <div class="custom_1i2 clearfix">
	  <h6>Donated<span class="pull-right col_1 bold">$12300</span></h6>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="footer">
  <div class="container">
   <div class="row">
    <div class="footer_1 clearfix">
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">About Us</h3>
	   <hr>
	   <ul>
	    <li><a href="#">About Us</a></li>
		<li><a href="#">Our Team</a></li>
		<li><a href="#">Volunteer Engagement</a></li>
		<li><a href="#">Communications</a></li>
		<li class="border_none"><a href="#">Services</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Discover</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Mission</a></li>
		<li><a href="#">Where We are Headed</a></li>
		<li><a href="#">History</a></li>
		<li><a href="#">Board and Staff</a></li>
		<li class="border_none"><a href="#">Join Our Team</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Support</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Terms of Use</a></li>
		<li><a href="#">Privacy Policy</a></li>
		<li><a href="#">Donor Privacy Policy</a></li>
		<li><a href="#">Internship</a></li>
		<li class="border_none"><a href="#">Copyright Notice</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">News</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Press Room</a></li>
		<li><a href="#">Effectiveness & Results</a></li>
		<li><a href="#">Advisory Panel</a></li>
		<li><a href="#">Endorsements</a></li>
		<li class="border_none"><a href="#">Annual Report</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
	<div class="footer_2 clearfix">
	 <div class="col-sm-6">
	  <div class="footer_2l clearfix">
       <p>© 2013 Your Website Name. All Rights Reserved | Design by <a class="col" href="http://www.templateonweb.com">TemplateOnWeb</a></p>
	  </div>
	 </div>
	 <div class="col-sm-6">
	  <div class="footer_2r clearfix">
       <ul>
	    <li><a href="#">Home</a></li>
		<li><a href="#">What we do</a></li>
		<li><a href="#">About</a></li>
		<li><a href="#">FAQ</a></li>
		<li><a href="#">Get involved</a></li>
		<li><a href="#">Team</a></li>
		<li><a href="#">News</a></li>
		<li><a href="#">Contacts</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
   </div>
  </div>
</section>

<div id="toTop" class="btn btn-info" style="display: block; background:#d43c18; color:#fff; border-color:#d43c18;"><span class="fa fa-chevron-up"></span></div>

<script>
$(document).ready(function(){
  $('body').append('<div id="toTop" class="btn btn-info"><span class="glyphicon glyphicon-chevron-up"></span> Back to Top</div>');
	$(window).scroll(function () {
		if ($(this).scrollTop() != 0) {
			$('#toTop').fadeIn();
		} else {
			$('#toTop').fadeOut();
		}
	});
$('#toTop').click(function(){
	$("html, body").animate({ scrollTop: 0 }, 600);
	return false;
});
});

</script>
@endsection
