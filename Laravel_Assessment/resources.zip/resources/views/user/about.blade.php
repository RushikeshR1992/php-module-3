
@extends('user.master')
@section('content')



<section id="center" class="clearfix center_about">
 <div class="container">
  <div class="row">
   <div class="center_about_1 clearfix">
    <div class="col-sm-6">
	 <div class="center_about_1l clearfix">
	  <h3 class="mgt">About</h3>
	 </div>
	</div>
	<div class="col-sm-6">
	 <div class="center_about_1r text-center clearfix">
	  <ul class="mgt">
	   <li><a href="#">Home</a></li> /
	   <li>About</li>
	  </ul>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="about_page" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="about_page_1 clearfix">
    <div class="col-sm-6">
	 <div class="about_page_1l clearfix">
	  <img src="img/23.jpg" class="iw" alt="abc">
	 </div>
	</div>
	<div class="col-sm-6">
	 <div class="about_page_1r clearfix">
	  <h3 class="mgt bold">Who We Are</h3>
	  <h4>We are here not for income, but for outcome</h4>
	  <p>Lorem Aenean nec quam efficitur, volutpat felis quis, commodo lacus. Morbi feugiat orci vel urna semper, ac tempus nunc luctus. Etiam quis placerat purus. Nulla fringilla varius lacus, eget eleifend sapien malesuada eget. Phasellus porta magna diam, ut accumsan massa semper in. Aliquam elit lectus, tincidunt eget vulputate vel, faucibus vitae elit. Donec sit amet quam facilisis, hendrerit lacus vitae, commodo dui. Nam consectetur ex nibh, id vulputate ex lacinia nec. Suspendisse nisi ante, luctus vel vestibulum in, commodo non dui. Suspendisse potenti. Nulla euismod lacus elit, vitae malesuada leo varius eu. Nam non quam posuere, facilisis augue sit amet, eleifend augue. In quis elit quis risus ornare tristique.</p>
	  <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean dolor leo, scelerisque ac mauris vitae!”</p>
	  <h5 class="text-right bold col_1">Semper Porta</h5>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="history" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="history_1 text-center clearfix">
    <div class="col-sm-12">
	 <h3 class="bold mgt">Our History</h3>
	 <p>Helping others is not a job, it is a calling</p>
	</div>
   </div>
   <div class="history_2 mgt clearfix">
    <div class="col-sm-4">
	 <div class="history_2l clearfix">
	  <div class="col-sm-3 space_left">
	   <span><i class="fa fa-heart-o"></i></span>
	  </div>
	  <div class="col-sm-9">
	   <h4 class="mgt bold">Where It All Began</h4>
	   <p>Quisque in mollis sem. Integer malesuada laoreet mauris, ac bibendum lacus feugiat id bibenqaw. Aenean non suscipit quam, a cursus metus.</p>
	  </div>
	 </div>
	</div>
	<div class="col-sm-4">
	 <div class="history_2c clearfix">
	  <a href="#"><img src="img/24.jpg" class="iw" alt="abc"></a>
	 </div>
	</div>
	<div class="col-sm-4">
	 <div class="history_2l clearfix">
	  <div class="col-sm-3 space_left">
	   <span><i class="fa fa-thumbs-o-up"></i></span>
	  </div>
	  <div class="col-sm-9">
	   <h4 class="mgt bold">Where It All Began</h4>
	   <p>Quisque in mollis sem. Integer malesuada laoreet mauris, ac bibendum lacus feugiat id bibenqaw. Aenean non suscipit quam, a cursus metus.</p>
	  </div>
	 </div>
	</div>
   </div>
   <div class="history_2 clearfix">
    <div class="col-sm-4">
	 <div class="history_2l clearfix">
	  <div class="col-sm-3 space_left">
	   <span><i class="fa fa-check"></i></span>
	  </div>
	  <div class="col-sm-9">
	   <h4 class="mgt bold">Where It All Began</h4>
	   <p>Quisque in mollis sem. Integer malesuada laoreet mauris, ac bibendum lacus feugiat id bibenqaw. Aenean non suscipit quam, a cursus metus.</p>
	  </div>
	 </div>
	</div>
	<div class="col-sm-4">
	 <div class="history_2c clearfix">
	  <a href="#"><img src="img/25.jpg" class="iw" alt="abc"></a>
	 </div>
	</div>
	<div class="col-sm-4">
	 <div class="history_2l clearfix">
	  <div class="col-sm-3 space_left">
	   <span><i class="fa fa-user-plus"></i></span>
	  </div>
	  <div class="col-sm-9">
	   <h4 class="mgt bold">Where It All Began</h4>
	   <p>Quisque in mollis sem. Integer malesuada laoreet mauris, ac bibendum lacus feugiat id bibenqaw. Aenean non suscipit quam, a cursus metus.</p>
	  </div>
	 </div>
	</div>
   </div>
   <div class="history_2 clearfix">
    <div class="col-sm-4">
	 <div class="history_2l clearfix">
	  <div class="col-sm-3 space_left">
	   <span><i class="fa fa-flag"></i></span>
	  </div>
	  <div class="col-sm-9">
	   <h4 class="mgt bold">Where It All Began</h4>
	   <p>Quisque in mollis sem. Integer malesuada laoreet mauris, ac bibendum lacus feugiat id bibenqaw. Aenean non suscipit quam, a cursus metus.</p>
	  </div>
	 </div>
	</div>
	<div class="col-sm-4">
	 <div class="history_2c clearfix">
	  <a href="#"><img src="img/26.jpg" class="iw" alt="abc"></a>
	 </div>
	</div>
	<div class="col-sm-4">
	 <div class="history_2l clearfix">
	  <div class="col-sm-3 space_left">
	   <span><i class="fa fa-star-o"></i></span>
	  </div>
	  <div class="col-sm-9">
	   <h4 class="mgt bold">Where It All Began</h4>
	   <p>Quisque in mollis sem. Integer malesuada laoreet mauris, ac bibendum lacus feugiat id bibenqaw. Aenean non suscipit quam, a cursus metus.</p>
	  </div>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="team_page" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="history_1 text-center clearfix">
    <div class="col-sm-12">
	 <h3 class="bold mgt">Our Team</h3>
	 <p>This wonderfull people make it all possible</p>
	</div>
   </div>
   <div class="team_p_1  clearfix">
    <div class="col-sm-3">
	 <div class="team_p_1i text-center clearfix">
	  <hr>
	  <a href="#"><img src="img/19.jpg" class="iw" alt="abc"></a>
	  <h4 class="bold"><a href="#">Semper Porta</a></h4>
	  <h5 class="col_1">Social Worker</h5>
	  <ul class="social-network social-circle">
                        <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
      </ul>
	  <p>Etiam eu molestie eros, commodo hendrerit sapien.</p>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="team_p_1i text-center clearfix">
	  <hr>
	  <a href="#"><img src="img/20.jpg" class="iw" alt="abc"></a>
	  <h4 class="bold"><a href="#">Mauris Massa</a></h4>
	  <h5 class="col_1">Social Worker</h5>
	  <ul class="social-network social-circle">
                        <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
      </ul>
	  <p>Etiam eu molestie eros, commodo hendrerit sapien.</p>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="team_p_1i text-center clearfix">
	  <hr>
	  <a href="#"><img src="img/21.jpg" class="iw" alt="abc"></a>
	  <h4 class="bold"><a href="#">Lacinia Arcu</a></h4>
	  <h5 class="col_1">Social Worker</h5>
	  <ul class="social-network social-circle">
                        <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
      </ul>
	  <p>Etiam eu molestie eros, commodo hendrerit sapien.</p>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="team_p_1i text-center clearfix">
	  <hr>
	  <a href="#"><img src="img/22.jpg" class="iw" alt="abc"></a>
	  <h4 class="bold"><a href="#">Eget Nulla</a></h4>
	  <h5 class="col_1">Social Worker</h5>
	  <ul class="social-network social-circle">
                        <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
      </ul>
	  <p>Etiam eu molestie eros, commodo hendrerit sapien.</p>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="footer">
  <div class="container">
   <div class="row">
    <div class="footer_1 clearfix">
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">About Us</h3>
	   <hr>
	   <ul>
	    <li><a href="#">About Us</a></li>
		<li><a href="#">Our Team</a></li>
		<li><a href="#">Volunteer Engagement</a></li>
		<li><a href="#">Communications</a></li>
		<li class="border_none"><a href="#">Services</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Discover</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Mission</a></li>
		<li><a href="#">Where We are Headed</a></li>
		<li><a href="#">History</a></li>
		<li><a href="#">Board and Staff</a></li>
		<li class="border_none"><a href="#">Join Our Team</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Support</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Terms of Use</a></li>
		<li><a href="#">Privacy Policy</a></li>
		<li><a href="#">Donor Privacy Policy</a></li>
		<li><a href="#">Internship</a></li>
		<li class="border_none"><a href="#">Copyright Notice</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">News</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Press Room</a></li>
		<li><a href="#">Effectiveness & Results</a></li>
		<li><a href="#">Advisory Panel</a></li>
		<li><a href="#">Endorsements</a></li>
		<li class="border_none"><a href="#">Annual Report</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
	<div class="footer_2 clearfix">
	 <div class="col-sm-6">
	  <div class="footer_2l clearfix">
       <p>© 2013 Your Website Name. All Rights Reserved | Design by <a class="col" href="http://www.templateonweb.com">TemplateOnWeb</a></p>
	  </div>
	 </div>
	 <div class="col-sm-6">
	  <div class="footer_2r clearfix">
       <ul>
	    <li><a href="#">Home</a></li>
		<li><a href="#">What we do</a></li>
		<li><a href="#">About</a></li>
		<li><a href="#">FAQ</a></li>
		<li><a href="#">Get involved</a></li>
		<li><a href="#">Team</a></li>
		<li><a href="#">News</a></li>
		<li><a href="#">Contacts</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
   </div>
  </div>
</section>

<div id="toTop" class="btn btn-info" style="display: block; background:#d43c18; color:#fff; border-color:#d43c18;"><span class="fa fa-chevron-up"></span></div>


<script>
$(document).ready(function(){
  $('body').append('<div id="toTop" class="btn btn-info"><span class="glyphicon glyphicon-chevron-up"></span> Back to Top</div>');
	$(window).scroll(function () {
		if ($(this).scrollTop() != 0) {
			$('#toTop').fadeIn();
		} else {
			$('#toTop').fadeOut();
		}
	});
$('#toTop').click(function(){
	$("html, body").animate({ scrollTop: 0 }, 600);
	return false;
});
});

</script>
@endsection
