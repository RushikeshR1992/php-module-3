@extends('user.master')
@section('content')



<section id="center" class="clearfix center_about">
 <div class="container">
  <div class="row">
   <div class="center_about_1 clearfix">
    <div class="col-sm-6">
	 <div class="center_about_1l clearfix">
	  <h3 class="mgt">Blog Detail</h3>
	 </div>
	</div>
	<div class="col-sm-6">
	 <div class="center_about_1r text-center clearfix">
	  <ul class="mgt">
	   <li><a href="#">Home</a></li> /
	   <li>Detail</li>
	  </ul>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="detail" class="clearfix">
 <div class="container">
  <div class="row">
    <div class="detail_1 clearfix">
	 <div class="col-sm-9 clearfix">
	  <div class="detail_1l clearfix">
	    <a href="#"><img src="img/33.jpg" alt="abc" class="iw"></a>
		<div class="blog_p_1lii clearfix">
           <h3 class="bold mgt"><a href="#">Disability is not the end of your career</a> <span class="pull-right col_1"><i class="fa fa-pencil"></i></span></h3>
		   <h6>By <a class="col_1" href="#">Semper Porta</a></h6>
		   <h6>In <a class="col_1" href="#">Donations</a>, <a class="col_1" href="#">Events</a></h6>
		   <h6 class="bor_t">On April 15, 2015 <a class="pull-right" href="#"> 0 <i class="fa fa-comment-o"></i></a></h6>
		   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices ipsum non mattis pharetra. Integer laoreet non felis sit amet pharetra. Integer mollis eget felis non finibus. Nullam nibh mauris, fermentum vitae felis vehicula, aliquam bibendum sapien. In euismod velit vitae neque rhoncus congue. Aliquam luctus, sapien in consectetur cursus, quam urna euismod magna, sed pellentesque massa libero eu lorem. Aenean rhoncus gravida nisl vel pretium. Nam ac nisl non ipsum vestibulum vehicula vulputate sagittis magna. Aenean est nisl, convallis volutpat tempor ac, tempus ac ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce rhoncus sodales tempor. Nunc pretium tortor felis, eget cursus magna accumsan a.</p>
		   <p>Etiam eu molestie eros, commodo hendrerit sapien. Maecenas tempus leo ac nisi iaculis porta. Sed sapien tortor, aliquet a velit ut, lacinia molestie velit. Maecenas ornare consequat massa ullamcorper dapibus. Aliquam auctor, sapien sit amet accumsan facilisis, enim enim aliquet arcu, tincidunt pellentesque justo turpis id neque. Duis eleifend nunc sit amet mi dapibus ornare. Suspendisse vel libero sem.</p>
		   <p>Sed nec blandit nibh. Pellentesque commodo suscipit gravida. Sed sit amet ex sed mi dignissim elementum in ut quam. Vivamus laoreet non mauris eget mattis. Nam turpis orci, consectetur vel accumsan sed, condimentum at sapien. Nunc ut egestas neque, eu hendrerit lacus. Suspendisse fermentum congue dui nec fringilla. Duis volutpat nunc lectus. Suspendisse potenti. Suspendisse egestas venenatis nunc. Donec at laoreet lacus.</p>
		   <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam quam elit, mollis at odio gravida, ultrices pulvinar justo. Vivamus eleifend mollis dolor, et ornare <a class="col_1 bold" href="#">turpis vehicula</a> in. Pellentesque auctor ac enim sit amet euismod commander cialis france. Ut eu accumsan nunc. Nam ultrices, orci a volutpat molestie, ipsum magna posuere ex, vel lobortis dolor purus tristique purus. Integer arcu libero, feugiat non eros vel, aliquet sodales justo. Aliquam lobortis efficitur velit, vel tempor dui iaculis non. Mauris non ullamcorper leo. Nulla consectetur arcu eget condimentum auctor. Aliquam sagittis dictum augue. Duis fringilla nec augue eu laoreet.</p>
		  </div>
	  </div>
	  <div class="detail_1l1 clearfix">
	   <ul>
	    <li><i class="fa fa-chevron-right"></i> <a href="#">Elderly care and support volunteering</a></li>
	    <li class="pull-right"><a href="#">There is Hope for everyone</a> <i class="fa fa-chevron-right"></i></li>
	   </ul>
	  </div>
	  <div class="detail_1l2 clearfix">
	   <h4 class="bold">Share this post?</h4>
	   <ul>
	    <li><a class="col_1" href="#">Facebook</a></li>
		<li><a class="col_1" href="#">Twitter</a></li>
		<li><a class="col_1" href="#">Pinterest</a></li>
	   </ul><br>
	   <h4 class="bold">About author</h4>
	  </div>
	  <div class="detail_1l3 clearfix">
	   <div class="col-sm-3">
	    <img src="img/19.jpg" alt="abc" class="iw">
	   </div>
	   <div class="col-sm-9">
	    <h4 class="mgt bold">Semper Porta (Semper Porta)</h4>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin aliquet erat diam, tristique euismod ligula interdum sed. Nam sit amet eros in ante pulvinar hendrerit in nec augue. Vivamus lacinia eros lectus, eu hendrerit lorem malesuada sit amet.</p>
		<h6><a class="col_1" href="#">http://info@gmail.com</a></h6>
	   </div>
	  </div>

	  <div class="detail_1l4 clearfix">
	   <h4 class="bold">More posts</h4>
	  </div>

	  <div class="event_h1r2 clearfix">
	   <div class="col-sm-12 space_all">
		  <ul class="mgt">
		  <li class="active"><a data-toggle="tab" href="#home">Event</a></li>
		  <li><a data-toggle="tab" href="#menu1">Press</a></li>
		  <li><a data-toggle="tab" href="#menu2">Video</a></li>
		</ul>
	   </div>
      </div>
	  <div class="event_h1r3 clearfix">
			<div class="tab-content clearfix">
			  <div id="home" class="tab-pane fade in active clearfix">
				 <div class="click clearfix">
		          <div class="home_i col-sm-12 space_all clearfix">
				   <h4 class="mgt bold">Hooray!</h4>
				   <p>Aras nec imperdiet neque. Vestibulum sem libero, ultrices sit amet elit at, aliquet accumsan purus. Suspendisse interdum felis at odio molestie, at elementum nisi dictum. Donec ac ultricies nisl. Nam posuere accumsan diam, vel mattis nibh volutpat hendrerit. Curabitur ultrices auctor nisl, vel ultricies massa euismod sed. Etiam at imperdiet nulla.</p>
				  </div>
				 </div>
			  </div>
			  <div id="menu1" class="tab-pane fade clearfix">
				 <div class="click clearfix">
				   <div class="home_i col-sm-12 space_all clearfix">
				   <h4 class="mgt bold">Jobs for disabled people</h4>
				   <p>Etiam eu molestie eros, commodo hendrerit sapien. Maecenas tempus leo ac nisi iaculis porta. Sed sapien tortor, aliquet a velit ut, lacinia molestie velit. Maecenas ornare consequat massa ullamcorper dapibus. Aliquam auctor, sapien sit amet accumsan facilisis, enim enim aliquet arcu, tincidunt pellentesque justo turpis id neque. Duis eleifend nunc sit amet mi dapibus ornare. Suspendisse vel libero sem.</p>
				   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices ipsum non mattis pharetra. Integer laoreet non felis sit amet pharetra. Integer mollis eget felis non finibus.</p>
				  </div>

				 </div>
			  </div>
			  <div id="menu2" class="tab-pane fade clearfix">
				 <div class="click clearfix">
				   <div class="home_i col-sm-12 space_all clearfix">
				    <h4 class="mgt bold">Hooray!</h4>
				   <p>Aras nec imperdiet neque. Vestibulum sem libero, ultrices sit amet elit at, aliquet accumsan purus. Suspendisse interdum felis at odio molestie, at elementum nisi dictum. Donec ac ultricies nisl. Nam posuere accumsan diam, vel mattis nibh volutpat hendrerit. Curabitur ultrices auctor nisl, vel ultricies massa euismod sed. Etiam at imperdiet nulla.</p>
				  </div>
				 </div>
			  </div>
            </div>
		</div>

	  <div class="blog_d_page_li3 clearfix">
	     <div class="about_h clearfix">
			 <h4 class="bold">Leave a Reply</h4>
       </div>
	     <div class="blog_d_page_li3i clearfix">
		  <div class="col-sm-6 space_left">
		   <input class="form-control" type="text" placeholder="Name">
		  </div>
		  <div class="col-sm-6 space_right">
		   <input class="form-control" type="text" placeholder="Email">
		  </div>
		 </div>
		 <div class="blog_d_page_li3i cleafix">
		  <div class="col-sm-12 space_all">
		   <textarea placeholder="Message" class="form-control form_1"></textarea>
		   <h5><a class="button" href="#">Add Comment </a></h5>
		  </div>

		 </div>
	   </div>
	 </div>
	 <div class="col-sm-3">
	 <div class="blog_p_1r clearfix">
	   <div class="input-group blog_p_1ri clearfix">
		<input type="text" class="form-control" placeholder="Keyword">
		<span class="input-group-btn">
			<button class="btn btn-primary" type="button">
				<i class="fa fa-search"></i>
			</button>
		</span>
	   </div>
	   <div class="blog_p_1ri1 clearfix">
		 <h3 class="mgt">Blog <span class="col_1">Categories</span></h3>
		 <h5><a href="#">Sed eget tellus</a> <span class="pull-right">(03)</span></h5>
		 <h5><a href="#">Fusce congue ultrices</a> <span class="pull-right">(04)</span></h5>
		 <h5><a href="#">Sed venenatis ligula turpis</a> <span class="pull-right">(05)</span></h5>
		 <h5><a href="#">Duis convallis tortor</a> <span class="pull-right">(18)</span></h5>
		 <h5 class="border_none"><a href="#">Pellentesque tempor</a> <span class="pull-right">(16)</span></h5>
	   </div>

	   <div class="blog_p_1ri3 clearfix">
	    <h3 class="mgt">New <span class="col_1">Archives</span></h3>
		<h5><a href="#"><span>13</span> June 2015</a></h5>
		<h5><a href="#"><span>17</span> May 2016</a></h5>
		<h5><a href="#"><span>19</span> July 2017</a></h5>
		<h5><a href="#"><span>15</span> December 2018</a></h5>
	   </div>
	   <div class="blog_p_1ri3 clearfix">
	    <h3 class="mgt">Popular <span class="col_1">Tags</span></h3>
		 <ul>
		  <li><a href="#">Table</a></li>
		  <li><a href="#">Chairs</a></li>
		  <li><a href="#">Window</a></li>
		  <li><a href="#">Interior Wall</a></li>
		  <li><a href="#">Furnitures</a></li>
		 </ul>
	   </div>
	 </div>
	</div>
	</div>
  </div>
 </div>
</section>

<section id="footer">
  <div class="container">
   <div class="row">
    <div class="footer_1 clearfix">
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">About Us</h3>
	   <hr>
	   <ul>
	    <li><a href="#">About Us</a></li>
		<li><a href="#">Our Team</a></li>
		<li><a href="#">Volunteer Engagement</a></li>
		<li><a href="#">Communications</a></li>
		<li class="border_none"><a href="#">Services</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Discover</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Mission</a></li>
		<li><a href="#">Where We are Headed</a></li>
		<li><a href="#">History</a></li>
		<li><a href="#">Board and Staff</a></li>
		<li class="border_none"><a href="#">Join Our Team</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Support</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Terms of Use</a></li>
		<li><a href="#">Privacy Policy</a></li>
		<li><a href="#">Donor Privacy Policy</a></li>
		<li><a href="#">Internship</a></li>
		<li class="border_none"><a href="#">Copyright Notice</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">News</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Press Room</a></li>
		<li><a href="#">Effectiveness & Results</a></li>
		<li><a href="#">Advisory Panel</a></li>
		<li><a href="#">Endorsements</a></li>
		<li class="border_none"><a href="#">Annual Report</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
	<div class="footer_2 clearfix">
	 <div class="col-sm-6">
	  <div class="footer_2l clearfix">
       <p>© 2013 Your Website Name. All Rights Reserved | Design by <a class="col" href="http://www.templateonweb.com">TemplateOnWeb</a></p>
	  </div>
	 </div>
	 <div class="col-sm-6">
	  <div class="footer_2r clearfix">
       <ul>
	    <li><a href="#">Home</a></li>
		<li><a href="#">What we do</a></li>
		<li><a href="#">About</a></li>
		<li><a href="#">FAQ</a></li>
		<li><a href="#">Get involved</a></li>
		<li><a href="#">Team</a></li>
		<li><a href="#">News</a></li>
		<li><a href="#">Contacts</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
   </div>
  </div>
</section>

<div id="toTop" class="btn btn-info" style="display: block; background:#d43c18; color:#fff; border-color:#d43c18;"><span class="fa fa-chevron-up"></span></div>

<script>
$(document).ready(function(){
  $('body').append('<div id="toTop" class="btn btn-info"><span class="glyphicon glyphicon-chevron-up"></span> Back to Top</div>');
	$(window).scroll(function () {
		if ($(this).scrollTop() != 0) {
			$('#toTop').fadeIn();
		} else {
			$('#toTop').fadeOut();
		}
	});
$('#toTop').click(function(){
	$("html, body").animate({ scrollTop: 0 }, 600);
	return false;
});
});

</script>

@endsection
