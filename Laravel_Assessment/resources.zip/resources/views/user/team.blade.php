@extends('user.master')
@section('content')



<section id="center" class="clearfix center_about">
 <div class="container">
  <div class="row">
   <div class="center_about_1 clearfix">
    <div class="col-sm-6">
	 <div class="center_about_1l clearfix">
	  <h3 class="mgt">Team</h3>
	 </div>
	</div>
	<div class="col-sm-6">
	 <div class="center_about_1r text-center clearfix">
	  <ul class="mgt">
	   <li><a href="#">Home</a></li> /
	   <li>Team</li>
	  </ul>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="team" class="clearfix">
 <div class="container">
  <div class="row">
    <div class="history_1 text-center clearfix">
    <div class="col-sm-12">
	 <h3 class="bold mgt">Our Team</h3>
	 <p>This awesome people make it all possible</p>
	</div>
   </div>
    <div class="team_1 clearfix">
	 <div class="col-sm-3">
	  <a href="#"><img src="img/20.jpg" class="iw" alt="abc"></a>
	 </div>
	 <div class="col-sm-3">
	  <h5 class="mgt col_1">Counsellor</h5>
	  <h4 class="bold"><a href="#">Semper Porta</a></h4>
	  <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean dolor leo, scelerisque ac mauris vitae!”</p>
	  <ul class="social-network social-circle">
                        <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
      </ul>
	 </div>
	 <div class="col-sm-6">
	  <p>
Etiam eu molestie eros, commodo hendrerit sapien. Maecenas tempus leo ac nisi iaculis porta. Sed sapien tortor, aliquet a velit ut, lacinia molestie velit. Maecenas ornare consequat massa ullamcorper dapibus. Aliquam auctor, sapien sit amet accumsan facilisis, enim enim aliquet arcu, tincidunt pellentesque justo turpis id neque. Duis eleifend nunc sit amet mi dapibus ornare. Suspendisse vel libero se Maecenas ornare consequat massa ullamcorper dapibus.</p>
	 </div>
	</div>
	<div class="team_p_1  clearfix">
    <div class="col-sm-3">
	 <div class="team_p_1i text-center clearfix">
	  <hr>
	  <a href="#"><img src="img/19.jpg" class="iw" alt="abc"></a>
	  <h4 class="bold"><a href="#">Semper Porta</a></h4>
	  <h5 class="col_1">Social Worker</h5>
	  <ul class="social-network social-circle">
                        <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
      </ul>
	  <p>Etiam eu molestie eros, commodo hendrerit sapien.</p>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="team_p_1i text-center clearfix">
	  <hr>
	  <a href="#"><img src="img/20.jpg" class="iw" alt="abc"></a>
	  <h4 class="bold"><a href="#">Mauris Massa</a></h4>
	  <h5 class="col_1">Social Worker</h5>
	  <ul class="social-network social-circle">
                        <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
      </ul>
	  <p>Etiam eu molestie eros, commodo hendrerit sapien.</p>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="team_p_1i text-center clearfix">
	  <hr>
	  <a href="#"><img src="img/21.jpg" class="iw" alt="abc"></a>
	  <h4 class="bold"><a href="#">Lacinia Arcu</a></h4>
	  <h5 class="col_1">Social Worker</h5>
	  <ul class="social-network social-circle">
                        <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
      </ul>
	  <p>Etiam eu molestie eros, commodo hendrerit sapien.</p>
	 </div>
	</div>
	<div class="col-sm-3">
	 <div class="team_p_1i text-center clearfix">
	  <hr>
	  <a href="#"><img src="img/22.jpg" class="iw" alt="abc"></a>
	  <h4 class="bold"><a href="#">Eget Nulla</a></h4>
	  <h5 class="col_1">Social Worker</h5>
	  <ul class="social-network social-circle">
                        <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
      </ul>
	  <p>Etiam eu molestie eros, commodo hendrerit sapien.</p>
	 </div>
	</div>
   </div>
   <div class="team_2 clearfix">
    <div class="col-sm-3">
	  <h5>Educability <span class="pull-right">50%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
		</div>
	  </div>
	  <h5>Experience <span class="pull-right">60%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
		</div>
	  </div>
	  <h5>Skills <span class="pull-right">91%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 91%">
		</div>
	  </div>
	</div>
	<div class="col-sm-3">
	  <h5>Educability <span class="pull-right">50%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
		</div>
	  </div>
	  <h5>Experience <span class="pull-right">60%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
		</div>
	  </div>
	  <h5>Skills <span class="pull-right">91%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 91%">
		</div>
	  </div>
	</div>
	<div class="col-sm-3">
	  <h5>Educability <span class="pull-right">50%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
		</div>
	  </div>
	  <h5>Experience <span class="pull-right">60%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
		</div>
	  </div>
	  <h5>Skills <span class="pull-right">91%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 91%">
		</div>
	  </div>
	</div>
	<div class="col-sm-3">
	  <h5>Educability <span class="pull-right">50%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
		</div>
	  </div>
	  <h5>Experience <span class="pull-right">60%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
		</div>
	  </div>
	  <h5>Skills <span class="pull-right">91%</span></h5>
	  <div class="progress">
		<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 91%">
		</div>
	  </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="team_last" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="team_last_1 clearfix">
    <div class="col-sm-4">
	 <div class="team_last_1i text-center clearfix">
	  <img src="img/34.jpg" class="iw" alt="abc"><br><br>
	  <h4 class="bold">Learn More About Welfare</h4>
	  <p>Phasellus dignissim leo at congue porttitor. Nunc in laoreet maximus ligula pretium, semper velit. Morbi sed luctus eros. Nullam et aliquam aug ue. Pellentesque a volutpat leo, atfrin gilla velit. In a sollicitudin lobortis.</p>
	  <h5><a class="button" href="#">Read more</a></h5>
	 </div>
	</div>
	<div class="col-sm-4">
	 <div class="team_last_1i text-center clearfix">
	  <img src="img/35.jpg" class="iw" alt="abc"><br><br>
	  <h4 class="bold">Sign Up for Our Newsletter</h4>
	  <p>Phasellus dignissim leo at congue porttitor. Nunc in laoreet maximus ligula pretium, semper velit. Morbi sed luctus eros. Nullam et aliquam aug ue. Pellentesque a volutpat leo, atfrin gilla velit. In a sollicitudin lobortis.</p>
	  <h5><a class="button" href="#">Sign up</a></h5>
	 </div>
	</div>
	<div class="col-sm-4">
	 <div class="team_last_1i text-center clearfix">
	  <img src="img/36.jpg" class="iw" alt="abc"><br><br>
	  <h4 class="bold">Make Your First Impact</h4>
	  <p>Phasellus dignissim leo at congue porttitor. Nunc in laoreet maximus ligula pretium, semper velit. Morbi sed luctus eros. Nullam et aliquam aug ue. Pellentesque a volutpat leo, atfrin gilla velit. In a sollicitudin lobortis.</p>
	  <h5><a class="button" href="#">Take action</a></h5>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="footer">
  <div class="container">
   <div class="row">
    <div class="footer_1 clearfix">
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">About Us</h3>
	   <hr>
	   <ul>
	    <li><a href="#">About Us</a></li>
		<li><a href="#">Our Team</a></li>
		<li><a href="#">Volunteer Engagement</a></li>
		<li><a href="#">Communications</a></li>
		<li class="border_none"><a href="#">Services</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Discover</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Mission</a></li>
		<li><a href="#">Where We are Headed</a></li>
		<li><a href="#">History</a></li>
		<li><a href="#">Board and Staff</a></li>
		<li class="border_none"><a href="#">Join Our Team</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Support</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Terms of Use</a></li>
		<li><a href="#">Privacy Policy</a></li>
		<li><a href="#">Donor Privacy Policy</a></li>
		<li><a href="#">Internship</a></li>
		<li class="border_none"><a href="#">Copyright Notice</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">News</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Press Room</a></li>
		<li><a href="#">Effectiveness & Results</a></li>
		<li><a href="#">Advisory Panel</a></li>
		<li><a href="#">Endorsements</a></li>
		<li class="border_none"><a href="#">Annual Report</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
	<div class="footer_2 clearfix">
	 <div class="col-sm-6">
	  <div class="footer_2l clearfix">
       <p>© 2013 Your Website Name. All Rights Reserved | Design by <a class="col" href="http://www.templateonweb.com">TemplateOnWeb</a></p>
	  </div>
	 </div>
	 <div class="col-sm-6">
	  <div class="footer_2r clearfix">
       <ul>
	    <li><a href="#">Home</a></li>
		<li><a href="#">What we do</a></li>
		<li><a href="#">About</a></li>
		<li><a href="#">FAQ</a></li>
		<li><a href="#">Get involved</a></li>
		<li><a href="#">Team</a></li>
		<li><a href="#">News</a></li>
		<li><a href="#">Contacts</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
   </div>
  </div>
</section>

<div id="toTop" class="btn btn-info" style="display: block; background:#d43c18; color:#fff; border-color:#d43c18;"><span class="fa fa-chevron-up"></span></div>

<script>
$(document).ready(function(){
  $('body').append('<div id="toTop" class="btn btn-info"><span class="glyphicon glyphicon-chevron-up"></span> Back to Top</div>');
	$(window).scroll(function () {
		if ($(this).scrollTop() != 0) {
			$('#toTop').fadeIn();
		} else {
			$('#toTop').fadeOut();
		}
	});
$('#toTop').click(function(){
	$("html, body").animate({ scrollTop: 0 }, 600);
	return false;
});
});

</script>

@endsection
