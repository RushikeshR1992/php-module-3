@extends('user.master')
@section('content')



<section id="center" class="clearfix center_about">
 <div class="container">
  <div class="row">
   <div class="center_about_1 clearfix">
    <div class="col-sm-6">
	 <div class="center_about_1l clearfix">
	  <h3 class="mgt">Blog</h3>
	 </div>
	</div>
	<div class="col-sm-6">
	 <div class="center_about_1r text-center clearfix">
	  <ul class="mgt">
	   <li><a href="#">Home</a></li> /
	   <li>Blog</li>
	  </ul>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="blog_page" class="clearfix">
 <div class="container">
  <div class="row">
    <div class="blog_p_1 clearfix">
	 <div class="col-sm-9">
	  <div class="blog_p_1l clearfix">
	   <div class="col-sm-6 space_left">
	    <div class="blog_p_1li clearfix">
		  <a href="detail"><img src="img/27.jpg" alt="abc" class="iw"></a>
		  <div class="blog_p_1lii clearfix">
           <h5 class="bold mgt"><a href="detail">Disability is not the end of your career</a> <span class="pull-right col_1"><i class="fa fa-pencil"></i></span></h5>
		   <h6>By <a class="col_1" href="detail">Semper Porta</a></h6>
		   <h6>In <a class="col_1" href="detail">Donations</a>, <a class="col_1" href="detail">Events</a></h6>
		   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices ipsum non mattis pharetra. Integer laoreet non felis sit amet...</p>
		   <h5 class="bold tc"><a href="detail">Read More</a></h5>
		   <h6 class="bor_t">On April 15, 2015 <a class="pull-right" href="detail"> 0 <i class="fa fa-comment-o"></i></a></h6>
		  </div>
		</div>
	   </div>
	   <div class="col-sm-6 space_left">
	    <div class="blog_p_1li clearfix">
		  <a href="detail"><img src="img/28.jpg" alt="abc" class="iw"></a>
		  <div class="blog_p_1lii clearfix">
           <h5 class="bold mgt"><a href="detail">There is Hope for everyone</a> <span class="pull-right col_1"><i class="fa fa-pencil"></i></span></h5>
		   <h6>By <a class="col_1" href="detail">Semper Porta</a></h6>
		   <h6>In <a class="col_1" href="detail">Donations</a>, <a class="col_1" href="detail">Events</a></h6>
		   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices ipsum non mattis pharetra. Integer laoreet non felis sit amet...</p>
		   <h5 class="bold tc"><a href="detail">Read More</a></h5>
		   <h6 class="bor_t">On April 15, 2015 <a class="pull-right" href="detail"> 0 <i class="fa fa-comment-o"></i></a></h6>
		  </div>
		</div>
	   </div>
	  </div>
	  <div class="blog_p_1l clearfix">
	   <div class="col-sm-6 space_left">
	    <div class="blog_p_1li clearfix">
		  <a href="detail"><img src="img/29.jpg" alt="abc" class="iw"></a>
		  <div class="blog_p_1lii clearfix">
           <h5 class="bold mgt"><a href="detail">Disability is not the end of your career</a> <span class="pull-right col_1"><i class="fa fa-pencil"></i></span></h5>
		   <h6>By <a class="col_1" href="detail">Semper Porta</a></h6>
		   <h6>In <a class="col_1" href="detail">Donations</a>, <a class="col_1" href="detail">Events</a></h6>
		   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices ipsum non mattis pharetra. Integer laoreet non felis sit amet...</p>
		   <h5 class="bold tc"><a href="detail">Read More</a></h5>
		   <h6 class="bor_t">On April 15, 2015 <a class="pull-right" href="detail"> 0 <i class="fa fa-comment-o"></i></a></h6>
		  </div>
		</div>
	   </div>
	   <div class="col-sm-6 space_left">
	    <div class="blog_p_1li clearfix">
		  <a href="detail"><img src="img/30.jpg" alt="abc" class="iw"></a>
		  <div class="blog_p_1lii clearfix">
           <h5 class="bold mgt"><a href="detail">There is Hope for everyone</a> <span class="pull-right col_1"><i class="fa fa-pencil"></i></span></h5>
		   <h6>By <a class="col_1" href="detail">Semper Porta</a></h6>
		   <h6>In <a class="col_1" href="detail">Donations</a>, <a class="col_1" href="detail">Events</a></h6>
		   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices ipsum non mattis pharetra. Integer laoreet non felis sit amet...</p>
		   <h5 class="bold tc"><a href="detail">Read More</a></h5>
		   <h6 class="bor_t">On April 15, 2015 <a class="pull-right" href="detail"> 0 <i class="fa fa-comment-o"></i></a></h6>
		  </div>
		</div>
	   </div>
	  </div>
	  <div class="blog_p_1l clearfix">
	   <div class="col-sm-6 space_left">
	    <div class="blog_p_1li clearfix">
		  <a href="det"><img src="img/31.jpg" alt="abc" class="iw"></a>
		  <div class="blog_p_1lii clearfix">
           <h5 class="bold mgt"><a href="detail">Disability is not the end of your career</a> <span class="pull-right col_1"><i class="fa fa-pencil"></i></span></h5>
		   <h6>By <a class="col_1" href="detail">Semper Porta</a></h6>
		   <h6>In <a class="col_1" href="detail">Donations</a>, <a class="col_1" href="detail">Events</a></h6>
		   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices ipsum non mattis pharetra. Integer laoreet non felis sit amet...</p>
		   <h5 class="bold tc"><a href="detail">Read More</a></h5>
		   <h6 class="bor_t">On April 15, 2015 <a class="pull-right" href="detail"> 0 <i class="fa fa-comment-o"></i></a></h6>
		  </div>
		</div>
	   </div>
	   <div class="col-sm-6 space_left">
	    <div class="blog_p_1li clearfix">
		  <a href="detail"><img src="img/32.jpg" alt="abc" class="iw"></a>
		  <div class="blog_p_1lii clearfix">
           <h5 class="bold mgt"><a href="detail">There is Hope for everyone</a> <span class="pull-right col_1"><i class="fa fa-pencil"></i></span></h5>
		   <h6>By <a class="col_1" href="detail">Semper Porta</a></h6>
		   <h6>In <a class="col_1" href="detail">Donations</a>, <a class="col_1" href="detail">Events</a></h6>
		   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices ipsum non mattis pharetra. Integer laoreet non felis sit amet...</p>
		   <h5 class="bold tc"><a href="detail">Read More</a></h5>
		   <h6 class="bor_t">On April 15, 2015 <a class="pull-right" href="detail"> 0 <i class="fa fa-comment-o"></i></a></h6>
		  </div>
		</div>
	   </div>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="blog_p_1r clearfix">
	   <h6 class="text-center mgt col">By <a class="col" href="detail">Semper Porta</a></h6>
	   <h6 class="text-center col">In <a class="col" href="detail">Donations</a>, <a class="col" href="detail">Support</a></h6>
	   <hr>
	   <span class="text-center col"><i class="fa fa-microphone"></i></span>
	   <p class="text-center col">No one has ever become poor by giving</p>
	   <h6 class="col bor_t">On April 15, 2015 <a class="pull-right col" href="detail"> 0 <i class="fa fa-comment-o"></i></a></h6>
	  </div>
	  <div class="blog_p_1r_1 clearfix">
	   <h6 class="text-center mgt">By <a class="col_1" href="detail">Semper Porta</a> In <a class="col_1" href="detail">Events</a></h6>
	   <hr>
	   <span class="text-center"><i class="fa fa-comment-o"></i></span>
	   <p class="text-center ">Volunteering is generally considered an altruistic activity and is intended to promote goodness or improve human quality of life. In return, this activity can produce a feeling of self-worth and respect.</p>
	   <h5 class="bold text-center">Wikipedia</h5>
	   <h6 class="bor_t">On April 15, 2015 <a class="pull-right" href="detail"> 0 <i class="fa fa-comment-o"></i></a></h6>
	  </div>
	  <div class="blog_p_1li clearfix">
		  <a href="detail"><img src="img/27.jpg" alt="abc" class="iw"></a>
		  <div class="blog_p_1lii clearfix">
           <h5 class="bold mgt"><a href="detail">Disability is not the end of your career</a> <span class="pull-right col_1"><i class="fa fa-pencil"></i></span></h5>
		   <h6>By <a class="col_1" href="detail">Semper Porta</a></h6>
		   <h6>In <a class="col_1" href="detail">Donations</a>, <a class="col_1" href="detail">Events</a></h6>
		   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultrices ipsum non mattis pharetra. Integer laoreet non felis sit amet...</p>
		   <h5 class="bold tc"><a href="detail">Read More</a></h5>
		   <h6 class="bor_t">On April 15, 2015 <a class="pull-right" href="detail"> 0 <i class="fa fa-comment-o"></i></a></h6>
		  </div>
		</div>
	 </div>
	</div>
  </div>
 </div>
</section>

<section id="footer">
  <div class="container">
   <div class="row">
    <div class="footer_1 clearfix">
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">About Us</h3>
	   <hr>
	   <ul>
	    <li><a href="#">About Us</a></li>
		<li><a href="#">Our Team</a></li>
		<li><a href="#">Volunteer Engagement</a></li>
		<li><a href="#">Communications</a></li>
		<li class="border_none"><a href="#">Services</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Discover</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Mission</a></li>
		<li><a href="#">Where We are Headed</a></li>
		<li><a href="#">History</a></li>
		<li><a href="#">Board and Staff</a></li>
		<li class="border_none"><a href="#">Join Our Team</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">Support</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Terms of Use</a></li>
		<li><a href="#">Privacy Policy</a></li>
		<li><a href="#">Donor Privacy Policy</a></li>
		<li><a href="#">Internship</a></li>
		<li class="border_none"><a href="#">Copyright Notice</a></li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	   <h3 class="col">News</h3>
	   <hr>
	   <ul>
	    <li><a href="#">Press Room</a></li>
		<li><a href="#">Effectiveness & Results</a></li>
		<li><a href="#">Advisory Panel</a></li>
		<li><a href="#">Endorsements</a></li>
		<li class="border_none"><a href="#">Annual Report</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
	<div class="footer_2 clearfix">
	 <div class="col-sm-6">
	  <div class="footer_2l clearfix">
       <p>© 2013 Your Website Name. All Rights Reserved | Design by <a class="col" href="http://www.templateonweb.com">TemplateOnWeb</a></p>
	  </div>
	 </div>
	 <div class="col-sm-6">
	  <div class="footer_2r clearfix">
       <ul>
	    <li><a href="#">Home</a></li>
		<li><a href="#">What we do</a></li>
		<li><a href="#">About</a></li>
		<li><a href="#">FAQ</a></li>
		<li><a href="#">Get involved</a></li>
		<li><a href="#">Team</a></li>
		<li><a href="#">News</a></li>
		<li><a href="#">Contacts</a></li>
	   </ul>
	  </div>
	 </div>
	</div>
   </div>
  </div>
</section>

<div id="toTop" class="btn btn-info" style="display: block; background:#d43c18; color:#fff; border-color:#d43c18;"><span class="fa fa-chevron-up"></span></div>


<script>
$(document).ready(function(){
  $('body').append('<div id="toTop" class="btn btn-info"><span class="glyphicon glyphicon-chevron-up"></span> Back to Top</div>');
	$(window).scroll(function () {
		if ($(this).scrollTop() != 0) {
			$('#toTop').fadeIn();
		} else {
			$('#toTop').fadeOut();
		}
	});
$('#toTop').click(function(){
	$("html, body").animate({ scrollTop: 0 }, 600);
	return false;
});
});

</script>
@endsection
