@extends('admin.master');
@section('content');

<h2>Add Events</h2>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-xl-6">
            <form id="formid" enctype="multipart/form-data">
                @csrf
                <div class="mb-3">
                    <label class="form-label">Image</label>
                    <input type="file" class="form-control" name="images" id="images">
                </div>
                <div class="mb-3">
                    <input type="submit" name="submit" id="submit" class="form-control">
                </div>
            </form>
        </div>
    </div>
</div>
<script>

    $('#formid').on('submit', function (e) {
        e.preventDefault();

        var Formdata = new FormData(this);

        // console.log(Formdata);

        $.ajax({
            url:"{{route('store_event')}}",
            type:'post',
            data:Formdata,
            dataType:'json',
            processData:false,
            contentType:false,
            success:function(res){
                console.log(res);
            }
        })
    })



</script>
@endsection
