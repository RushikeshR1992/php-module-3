@extends('admin.master');
@section('content')

<h5>Events Bars</h5>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-xl-6">
            <div class="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0"
                        class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
                        aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
                        aria-label="Slide 3"></button>
                </div>

                <table id="table"></table>
                <!-- Modal -->
                <div class="modal fade" id="modaledit" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Edit Events</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="formid" enctype="multipart/form-data">
                                    @csrf
                                    <div class="mb-3">
                                        <label class="form-label">Image</label>
                                        <input type="text" name="id" id="id">
                                        <input type="file" class="form-control" name="images" id="images">
                                        <div id="img"></div>
                                    </div>
                                    <div class="mb-3">
                                        <input type="submit" name="submit" id="submit" class="form-control">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>
        function getall() {
            $.ajax({
                url: '{{route('view_event')}}',
                type: 'get',
                success: function (res) {
                    // console.log(res);
                    $('#table').html(res);
                }
            })
        }
        getall();


        $(document).on('click', '.edit', function () {

            var id = $(this).attr('id');

            console.log(id);
            $.ajax({
                url: '{{route('edit_events')}}',
                type: 'get',
                data: { id: id },
                success: function (res) {
                    // console.log(res.images);
                    $('#id').val(res.id);
                    $('#img').html(`<img src='uploads/${res.images}' width='100px'>`);
                }
            })
        })
        $('#formid').on('submit', function (e) {
            e.preventDefault();

            var JsonData = new FormData(this);

            $.ajax({
                url: '{{route('update_events')}}',
                type: 'post',
                data: JsonData,
                dataType: 'json',
                contentType: false,
                processData: false,
                success: function (res) {
                    console.log(res);
                }
            })
        })



        $(document).on('click', '.delete', function () {

            var id = $(this).attr('id');
            console.log(id);

            $.ajax({
                url: '{{route('delete_events')}}',
                method: 'delete',
                data: {
                    id: id,
                    _token: "{{csrf_token()}}"
                },
                success: function (res) {
                    console.log(res);
                    getall();
                }
            })
        })
    </script>
    @endsection
