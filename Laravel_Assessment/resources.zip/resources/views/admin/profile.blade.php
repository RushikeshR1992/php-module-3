@include('admin.profile');
@section('content');
<div class="container">
    <div class="row justify-content-center">
        <div class="col-xl-6">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">First</th>
                        <th scope="col">Last</th>
                        <th scope="col">Handle</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($reg as $r)

                        <tr>
                            <th scope="row">{{$r->id}}</th>
                            <td>{{$r->name}}</td>
                            <td>Otto</td>
                            <td>@mdo</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
