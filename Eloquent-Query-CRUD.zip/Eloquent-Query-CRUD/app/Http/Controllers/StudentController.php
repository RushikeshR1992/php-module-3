<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    function index()
    {
        $student = Student::all();
        return view('students.index',compact('student'));
    }

    function create()
    {
        return view('students.create');
    }

    function store(request $request)
    {
        $student = new Student();

        if($request->file('image'))
        {
            $file = $request->image;
            $img = $file->getClientOriginalName();
            $file->move(public_path("images/"),$img);
        }
        $student->name = $request->name;
        $student->image = $img;
        $student->address = $request->address;

        $student->save();
        return redirect()->route('index');
    }

    function edit($id)
    {
        $student = Student::find($id);
        return view('students.edit',compact('student'));
    }

    function update(request $request,$id)
    {
        $student = Student::find($id);

        if($request->file('image'))
        {
            $file = $request->image;
            $img = $file->getClientOriginalName();
            $file->move(public_path("/images"),$img);
        }
        else
        {
            $img = $student->image;
        }
        $student->name = $request->name;
        $student->image = $img;
        $student->address = $request->address;

        $student->update();
        return redirect()->route('index');

    }

    function delete($id)
    {
        $id = Student::find($id);
        $id->delete();
        return redirect()->route('index');
    }
}
