<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    function index(request $request)
    {

        $user = new User();

        $email = $request->email;
        $data = $user->select('email')->where('email','=',$email)->first();

        // return $email;

        return response()->json($data);
    }


    function show(request $request)
    {
        return view('user.home');
    }


    function insert(request $request)
    {
        $user = new User();

        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = $request->password;
        $user->gender = $request->gender;
        $user->address = $request->address;
        $user->phone = $request->phone;

        $user->save();
        return view('login');
    }
    //  function show(request $request)
    // {
    //     $user = new users;

    //     $email = $request->email;
    //     $pass = $request->password;

    //     $run = $user->select('email')->where('email','=',$email)->first();
    //     $run1 = $user->select('password')->where('password','=',$pass)->first();
    //     $name = $user->select('name')->where('email','=',$email)->first();

    //    echo $name['name'];
    //    exit();
        
    //     // echo $run,$run1; exit();
    //     if(!empty($run) && !empty($run1))
    //     {
    //         return view('index');
    //     }
    //     else
    //     {
    //         return view('register');
    //     }
    // }
    function edit()
    {
        
    }
    function update()
    {
        
    }
    function delete()
    {
        
    }
    function login()
    {
        return view('user.login');
    }
    function register()
    {
        return view('register');
    }
}
