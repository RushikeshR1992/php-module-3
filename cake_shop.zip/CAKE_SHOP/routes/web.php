<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('index');
// });
Route::get('/',function(){
    return view('index');
});

Route::get('/adminpanel',[AdminController::class,'index'])->name('adminpanel');

Route::get('/userpanel',[UserController::class,'index'])->name('userpanel');

Route::get('/admin',[AdminController::class,'show'])->name('admin');

Route::get('/user',[UserController::class,'show'])->name('user');





Route::get('/about', function () {
    return view('about');
});
Route::get('/menu', function () {
    return view('menu');
});
Route::get('/team', function () {
    return view('team');
});
Route::get('/service', function () {
    return view('service');
});
Route::get('/testimonial', function () {
    return view('testimonial');
});
Route::get('/contact', function () {
    return view('contact');
});

Route::get('/login',[UserController::class,'login']);
Route::get('/register',[UserController::class,'register']);


