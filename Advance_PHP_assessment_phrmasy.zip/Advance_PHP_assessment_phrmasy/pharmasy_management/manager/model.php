<?php


class model
{
    public $conn = "";

    function __construct()
    {
        $this->conn = new mysqli('localhost', 'root', '', 'assessment');
        // echo "extenstion"; exit();
    }

    function insert($tbl, $data) //$tbl you can call the function  Which table And which data 
    {

        $col_arr = array_keys($data); //id,name,email
        $col = implode(',', $col_arr);
        $val_arr = array_values($data); //1,Rushikesh,r@gmail.com
        // $val=implode('','',$val_arr);
        $val = implode("','", $val_arr); //first double cote and under sigle cote
        //'name','hii' use for formate

        $sql = "insert into $tbl ($col) values ('$val')";
        // echo $sql;exit();
        $run = $this->conn->query($sql);
        return $run;
    }
    function update($tbl, $data, $where)
    {
        // data mathi column and value split karvu
        $col_arr = array_keys($data);
        $val_arr = array_values($data);

        //update table set col=val,col=val Half query finish
        $update = "update $tbl set ";

        $i = 0;
        $count = count($data);
        foreach ($data as $d) {
            if ($count <= $i + 1) {
                $update .= "$col_arr[$i] = '$val_arr[$i]'";
            } else {
                $update .= "$col_arr[$i] = '$val_arr[$i]',";
                $i++;
            }
        }
        // where col=val and col=val //end Query finished 

        $update .= "where 1=1";
        // spilt in where in column and value
        $wcol_arr = array_keys($where);
        $wval_arr = array_values($where);


        $j = 0;
        foreach ($where as $d1) {
            $update .= " and $wcol_arr[$j] = '$wval_arr[$j]'";
            $j++;
        }


        $run = $this->conn->query($update);
        if ($run) {
            header("location:index");
        }
        return $run;

    }
    function select($tbl)
    {
        $sql = "select * from $tbl";

        $run = $this->conn->query($sql);
        while ($fetch = $run->fetch_object()) {
            $arr[] = $fetch;
        }
        if (!empty($arr)) {
            return $arr;
        }
    }
    function select_where($tbl, $where)
    {
        $col_arr = array_keys($where);
        $val_arr = array_values($where);

        $select = "select * from $tbl where 1=1";

        $i = 0;
        foreach ($where as $w) {
            $select .= " and $col_arr[$i] = '$val_arr[$i]'";
            $i++;
        }
        // echo $select; exit();
        $run = $this->conn->query($select);

        if (!empty($run)) {
            return $run;
        }
    }
    function select_where_multiData($tbl, $where)
    {
        $col_arr = array_keys($where);
        $val_arr = array_values($where);

        $select = "select * from $tbl where 1=1";

        $i = 0;

        foreach ($where as $w) {
            $select .= " and $col_arr[$i] = '$val_arr[$i]'";
            $i++;
        }
        // echo $select; exit();
        $run = $this->conn->query($select);
        while ($ftech = $run->fetch_object()) {
            $arr[] = $ftech;
        }
        if (!empty($arr)) {
            return $arr;
        }
    }
    // select  from cart join singlemodel on cart.smodel_id =singlemodel.id where u_id=42
    function select_join_where_multidata($tbl1, $tbl2, $on, $where)
    {
        $sel = "select * from $tbl1 join $tbl2 on $on where 1=1";
        $col_arr = array_keys($where);
        $val_arr = array_values($where);

        $i = 0;

        foreach ($where as $c) {
            $sel .= " and $col_arr[$i]='$val_arr[$i]'";
            $i++;
        }
        $run = $this->conn->query($sel);

        while ($ftech = $run->fetch_object()) {
            $arr[] = $ftech;
        }
    }
    function delete_where($tbl,$where)
    {
        $wcol_arr = array_keys($where);
        $wval_arr = array_values($where);

        $del = "delete from $tbl where 1=1";//

        $i=0;
        foreach ($where as $d) {           
             $del .= " and  $wcol_arr[$i] = '$wval_arr[$i]'";      
            
         }

         $run = $this->conn->query($del);
        return $run;
    }
}