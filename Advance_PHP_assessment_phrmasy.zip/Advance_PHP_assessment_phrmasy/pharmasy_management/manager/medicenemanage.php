<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmasy System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <div class="conatiner ">
        <div class="row justify-content-center mt-5">
            <div class="col-xl-8">
                <div>
                    <h1>WelCome To Pharmasy Management System</h1>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">SR.No</th>
                            <th scope="col">Medicine Name</th>
                            <th scope="col">Qty</th>
                            <th scope="col">Added Date</th>
                            <th scope="col">Added BY</th>
                            <th scope="col">price</th>
                            <th scope="col">Handle</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            foreach($medicine as $medicinedetail)
                            {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $medicinedetail->medicine_id ?></th>
                            <td><?php echo $medi=$medicinedetail->medicine_name ?></td>
                            <td><?php echo $med_qty=$medicinedetail->medicine_qty ?></td>
                            <td><?php echo $medicinedetail->medicine_date ?></td>
                            <td><?php echo $med_add=$medicinedetail->medicine_add_by ?></td>
                            <td><?php echo $price=$med_qty*$medicinedetail->medicine_price ?></td>

                            <td><a href="addmedicene" class="btn btn-primary"><i
                                        class="fa-sharp fa-solid fa-notes-medical"></i></a>
                                <a href="editmedicine?edit=<?php echo $medicinedetail->medicine_id ?>" class="btn btn-danger "><i
                                        class="fa-solid fa-street-view"></i></a>
                                <a href="deletemedicene?deleId=<?php echo $medicinedetail->medicine_id ?>" class="btn btn-warning m-2 "><i
                                        class="fa-solid fa-trash"></i></a>
                            </td>
                        </tr>
                       <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>