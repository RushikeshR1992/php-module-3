<?php

include('model.php');

class controller extends model
{
    function __construct()
    {
        model::__construct();

        $url = $_SERVER["PATH_INFO"];

        switch ($url) {
            case '/index':
                include 'index.php';
                break;
            case '/register':

                if (isset($_POST['manregbtn'])) {
                    $manager_name = $_POST['mname'];
                    $mPharmacy_name = $_POST['mPharmacyname'];
                    $mpassword = $_POST['mpassword'];

                    $data = array('manager_name' => $manager_name, 'mphamacy_name' => $mPharmacy_name, 'manager_password' => $mpassword);

                    $minsert = $this->insert('pharmacy_manager', $data);

                    if ($minsert) {
                        echo "<script>
                            alert('Manager Ragister Successful'); 
                        </script>";
                    } else {
                        echo "<script>
                            alert('You Are Not Register'); 
                    </script>";
                    }
                }
                include 'register.php';
                break;
            case '/medicenemanage':
                $medicine = $this->select('add_medicine');

                include 'medicenemanage.php';
                break;
            case '/addmedicene':

                if (isset($_POST['medsub'])) {

                    $medicine_name = $_POST['medname'];
                    $m_qty = $_POST['medqty'];
                    $m_date = $_POST['meddate'];
                    $m_add = $_POST['medadd'];
                    $m_price = $_POST['medprice'];


                    $data = array('medicine_name' => $medicine_name, 'medicine_qty' => $m_qty, 'medicine_date' => $m_date, 'medicine_add_by' => $m_add, 'medicine_price' => $m_price);

                    $minsert = $this->insert('add_medicine', $data);

                    if ($minsert) {
                        echo "<script>
                            alert('Manager Ragister Successful'); 
                        </script>";
                    } else {
                        echo "<script>
                            alert('You Are Not Register'); 
                    </script>";
                    }
                }
                include 'addmedicene.php';
                break;

            case '/editmedicine':
                $id = $_GET['edit'];//eid-> view-user
                $where = array("medicine_id " => $id);//uid-databaseid 
                $run = $this->select_where('add_medicine', $where);//select * from users_reg 
                $fetch = $run->fetch_object();
                
                if (isset($_POST['medmedicine'])) {

                    $medicine_name = $_POST['medname'];
                    $med_qty = $_POST['medqty'];
                    $med_date = $_POST['meddate'];
                    $med_add = $_POST['medadd'];
                    $med_price = $_POST['medprice'];


                    $data = array('medicine_name' => $medicine_name, 'medicine_qty' => $med_qty, 'medicine_date' => $med_date, 'medicine_add_by' => $med_add, 'medicine_price' => $med_price);

                    $medicinedata=$this->update("add_medicine", $data, $where);

                    if ($medicinedata) {
                        echo "<script>
                            alert('update data'); 
                        </script>";
                    } else {
                        echo "<script>
                            alert('You Are Not Register'); 
                    </script>";
                    }
                }
                include 'editmedicine.php';
                break;
            case '/deletemedicene':
                $id =   $_GET['deleId'];
                $where = array('medicine_id'=>$id);//35

                $del = $this->delete_where('add_medicine',$where);

               if($del)
               {
                    header("location:medicenemanage");
               }
                

                
                
                include 'deletemedicene.php';
                break;
        }
    }
}
$obj = new controller();