<?php

include('model.php');

class controller extends model
{
    function __construct()
    {
        session_start();
        model::__construct();

        $url = $_SERVER["PATH_INFO"];

        switch ($url) {
            case '/index':
                include 'index.php';
                break;
            case '/register':

                if (isset($_POST['adminreg'])) {
                    $admin_name = $_POST['aname'];
                    $admin_email = $_POST['aemail'];
                    $admin_password = $_POST['apassword'];

                    $data = array('admin_name' => $admin_name, 'admin_email' => $admin_email, 'admin_password' => $admin_password);

                    $ainsert = $this->insert('admin', $data);

                    if ($ainsert) {
                        echo "<script>
                                alert('Admin Ragister Successful');
                            </script>";
                    } else {
                        echo "<script>
                                alert('You Are Not Register'); 
                        </script>";
                    }
                }
                include 'register.php';
                break;
            case '/login':
                if (isset($_POST['adminlogin'])) {
                    $auseremail = $_POST['aemail'];
                    $apassword = $_POST['apassword'];

                    $where = array("admin_email" => $auseremail, "admin_password" => $apassword);
                    $fetch_where = $this->select_where("admin", $where);
                    // echo $fetch_where;exit();
                    $dbauseremail = $fetch_where->admin_email;
                    $dbapassword = $fetch_where->admin_password;

                    $_SESSION['adminuseremail'] = $dbauseremail;

                    if ($dbauseremail == $auseremail && $dbapassword == $apassword) {
                        echo "<script>
                    alert('Wlecome Admin');
                    window.location.href='dashboard';
                    </script>";
                    } else {

                        echo "<script>
                    alert('Invalide Username Or Password')</script>";
                    }

                    // if(isset($_POST['keepmelogin']))
                    // {
                    //     setcookie('adminusername',$ausername,time()+30);
                    //     setcookie('adminpassword',$apassword,time()+30);
                    // }

                }
                include 'login.php';
                break;
            case '/logout':
                // unset($_SESSION['adminuseremail']);
                session_destroy();
                header('location:index');
                include 'logout.php';
                break;
            case '/dashboard':
                $medicine = $this->select('pharmacy_manager');
                include 'dashboard.php';
                break;

        }
    }
}
$obj = new controller();